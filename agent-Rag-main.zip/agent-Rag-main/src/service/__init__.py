from service.service import app

__all__ = ["app"]
