# Authentication-user-JWT
aplicación completa que demuestra el flujo completo de autenticación usando JWT (JSON Web Tokens), implementando todas las mejores prácticas de seguridad.



# 🔐 Aplicación de Autenticación JWT

Una aplicación completa que demuestra el flujo completo de autenticación usando JWT (JSON Web Tokens), implementando todas las mejores prácticas de seguridad.

## 📋 Características

### ✅ Flujo JWT Completo
- **Registro de usuarios** con validación y encriptación de contraseñas
- **Inicio de sesión** con generación de JWT y refresh tokens
- **Rutas protegidas** con middleware de autenticación
- **Control de acceso basado en roles** (RBAC)
- **Renovación automática de tokens** cuando expiran
- **Cierre de sesión seguro** con invalidación de tokens
- **Panel de administración** exclusivo para admins

### 🛡️ Seguridad Implementada
- Encriptación de contraseñas con bcrypt
- Tokens JWT con expiración configurable
- Refresh tokens para renovar sesiones
- Middleware de autenticación robusto
- Validación de roles en el servidor
- Rate limiting para prevenir ataques
- Headers de seguridad con Helmet
- CORS configurado correctamente

### 🎯 Tecnologías Utilizadas

**Backend:**
- Node.js + Express
- SQLite (base de datos)
- JWT (jsonwebtoken)
- bcryptjs (encriptación)
- Helmet (seguridad)
- CORS (Cross-Origin Resource Sharing)

**Frontend:**
- React 18
- React Router DOM
- Context API (gestión de estado)
- Axios (peticiones HTTP)
- CSS moderno con Grid y Flexbox

## 🚀 Instalación y Configuración

### Prerrequisitos
- Node.js (versión 16 o superior)
- npm o yarn

### 1. Clonar el repositorio
```bash
git clone <url-del-repositorio>
cd jwt-auth-app
```

### 2. Instalar dependencias
```bash
# Instalar dependencias del proyecto principal
npm install

# Instalar dependencias del servidor
cd server
npm install

# Instalar dependencias del cliente
cd ../client
npm install

# Volver al directorio raíz
cd ..
```

### 3. Configurar variables de entorno
El archivo `server/config.env` ya está configurado con valores por defecto, pero puedes modificarlo:

```env
PORT=5000
JWT_SECRET=tu_clave_secreta_super_segura_2024
JWT_EXPIRES_IN=1h
REFRESH_TOKEN_SECRET=tu_refresh_token_secreto_2024
REFRESH_TOKEN_EXPIRES_IN=7d
```

### 4. Ejecutar la aplicación

#### Opción A: Ejecutar todo junto
```bash
npm run dev
```

#### Opción B: Ejecutar por separado
```bash
# Terminal 1 - Servidor
cd server
npm run dev

# Terminal 2 - Cliente
cd client
npm start
```

### 5. Acceder a la aplicación
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:5000

## 🧪 Datos de Prueba

La aplicación incluye un usuario de administrador preconfigurado:

```
Email: admin@test.com
Contraseña: admin123
```

## 📚 API Endpoints

### Autenticación
- `POST /api/auth/register` - Registrar nuevo usuario
- `POST /api/auth/login` - Iniciar sesión
- `POST /api/auth/logout` - Cerrar sesión
- `POST /api/auth/refresh` - Renovar token
- `GET /api/auth/me` - Obtener información del usuario actual

### Usuarios (Protegidas)
- `GET /api/users/profile` - Obtener perfil del usuario
- `PUT /api/users/profile` - Actualizar perfil
- `DELETE /api/users/profile` - Eliminar cuenta
- `GET /api/users/protected` - Ruta protegida de ejemplo
- `GET /api/users/admin` - Panel de administración (solo admins)
- `GET /api/users/stats` - Estadísticas del sistema

### Utilidades
- `GET /api/health` - Estado del servidor

## 🔄 Flujo JWT Implementado

### 1. Registro/Login
```
Usuario → Envía credenciales → Servidor valida → Genera JWT → Cliente almacena
```

### 2. Acceso a Rutas Protegidas
```
Cliente → Incluye JWT en header → Servidor verifica → Permite acceso → Devuelve datos
```

### 3. Renovación de Tokens
```
Token expirado → Cliente detecta 401 → Usa refresh token → Obtiene nuevo JWT → Continúa
```

### 4. Cierre de Sesión
```
Usuario → Solicita logout → Servidor invalida refresh token → Cliente elimina tokens
```

## 🛡️ Características de Seguridad

### Middleware de Autenticación
- Verificación de firma JWT
- Validación de expiración
- Verificación de existencia del usuario en BD
- Manejo de errores específicos

### Control de Acceso
- Middleware de autorización por roles
- Verificación de permisos en cada ruta
- Respuestas apropiadas para acceso denegado

### Gestión de Tokens
- Access tokens de corta duración (1 hora)
- Refresh tokens de larga duración (7 días)
- Almacenamiento seguro en localStorage
- Renovación automática transparente

### Base de Datos
- Encriptación de contraseñas con bcrypt
- Integridad referencial
- Limpieza automática de tokens expirados
- Validación de datos

## 📱 Funcionalidades del Frontend

### Páginas Principales
- **Home:** Explicación del flujo JWT y características
- **Login:** Inicio de sesión con validación
- **Register:** Registro de nuevos usuarios
- **Dashboard:** Panel principal con información del usuario
- **Profile:** Gestión del perfil y cuenta
- **Admin Panel:** Panel exclusivo para administradores

### Características de UX
- Interfaz moderna y responsive
- Manejo de estados de carga
- Mensajes de error y éxito
- Navegación intuitiva
- Protección de rutas en el frontend

## 🔧 Configuración Avanzada

### Personalizar Tiempos de Expiración
```env
JWT_EXPIRES_IN=30m        # Access token: 30 minutos
REFRESH_TOKEN_EXPIRES_IN=30d  # Refresh token: 30 días
```

### Cambiar Base de Datos
La aplicación usa SQLite por simplicidad, pero puedes cambiar a:
- PostgreSQL
- MySQL
- MongoDB

Solo necesitas modificar el archivo `server/database/init.js`

### Configurar CORS
```javascript
// En server/index.js
app.use(cors({
  origin: ['http://localhost:3000', 'https://tu-dominio.com'],
  credentials: true
}));
```

## 🐛 Solución de Problemas

### Error: "Module not found"
```bash
# Reinstalar dependencias
rm -rf node_modules package-lock.json
npm install
```

### Error: "Port already in use"
```bash
# Cambiar puerto en server/config.env
PORT=5001
```

### Error: "Database locked"
```bash
# Eliminar archivo de base de datos y reiniciar
rm server/database/jwt_auth.db
npm run dev
```

### Error: "JWT expired"
- Los tokens se renuevan automáticamente
- Si persiste, verifica la configuración de tiempo en `config.env`

## 📈 Próximas Mejoras

- [ ] Implementar autenticación de dos factores (2FA)
- [ ] Agregar logs de auditoría
- [ ] Implementar blacklist de tokens
- [ ] Agregar rate limiting por usuario
- [ ] Implementar recuperación de contraseña
- [ ] Agregar tests unitarios y de integración
- [ ] Implementar WebSocket para notificaciones en tiempo real
- [ ] Agregar documentación con Swagger

## 🤝 Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 🙏 Agradecimientos

- [JWT.io](https://jwt.io/) por la documentación de JWT
- [Express.js](https://expressjs.com/) por el framework web
- [React](https://reactjs.org/) por la biblioteca de UI
- [bcryptjs](https://github.com/dcodeIO/bcrypt.js/) por la encriptación de contraseñas

---

**¡Disfruta explorando el flujo completo de autenticación JWT! 🔐** 
