const express = require('express');
const bcrypt = require('bcryptjs');
const { getDatabase } = require('../database/init');
const { authenticateToken, authenticateRefreshToken } = require('../middleware/auth');
const { 
  generateAccessToken, 
  generateRefreshToken, 
  saveRefreshToken, 
  removeRefreshToken 
} = require('../utils/jwt');

const router = express.Router();

// POST /api/auth/register - Registrar nuevo usuario
router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;

    // Validaciones
    if (!email || !password || !name) {
      return res.status(400).json({
        message: 'Todos los campos son requeridos',
        error: 'MISSING_FIELDS'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        message: 'La contraseña debe tener al menos 6 caracteres',
        error: 'PASSWORD_TOO_SHORT'
      });
    }

    const db = getDatabase();

    // Verificar si el usuario ya existe
    const checkUser = `SELECT id FROM users WHERE email = ?`;
    db.get(checkUser, [email], async (err, row) => {
      if (err) {
        return res.status(500).json({
          message: 'Error verificando usuario',
          error: 'DATABASE_ERROR'
        });
      }

      if (row) {
        return res.status(409).json({
          message: 'El usuario ya existe',
          error: 'USER_EXISTS'
        });
      }

      // Hash de la contraseña
      const hashedPassword = await bcrypt.hash(password, 10);

      // Insertar nuevo usuario
      const insertUser = `
        INSERT INTO users (email, password, name) 
        VALUES (?, ?, ?)
      `;

      db.run(insertUser, [email, hashedPassword, name], function(err) {
        if (err) {
          return res.status(500).json({
            message: 'Error creando usuario',
            error: 'DATABASE_ERROR'
          });
        }

        // Generar tokens
        const user = { id: this.lastID, email, name, role: 'user' };
        const accessToken = generateAccessToken(user);
        const refreshToken = generateRefreshToken(user);

        // Guardar refresh token
        saveRefreshToken(user.id, refreshToken)
          .then(() => {
            res.status(201).json({
              message: 'Usuario registrado exitosamente',
              user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role
              },
              accessToken,
              refreshToken
            });
          })
          .catch(err => {
            console.error('Error guardando refresh token:', err);
            res.status(500).json({
              message: 'Error en la autenticación',
              error: 'TOKEN_ERROR'
            });
          });
      });
    });
  } catch (error) {
    console.error('Error en registro:', error);
    res.status(500).json({
      message: 'Error interno del servidor',
      error: 'INTERNAL_ERROR'
    });
  }
});

// POST /api/auth/login - Iniciar sesión
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validaciones
    if (!email || !password) {
      return res.status(400).json({
        message: 'Email y contraseña son requeridos',
        error: 'MISSING_CREDENTIALS'
      });
    }

    const db = getDatabase();

    // Buscar usuario
    const getUser = `SELECT id, email, password, name, role FROM users WHERE email = ?`;
    db.get(getUser, [email], async (err, user) => {
      if (err) {
        return res.status(500).json({
          message: 'Error verificando credenciales',
          error: 'DATABASE_ERROR'
        });
      }

      if (!user) {
        return res.status(401).json({
          message: 'Credenciales inválidas',
          error: 'INVALID_CREDENTIALS'
        });
      }

      // Verificar contraseña
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({
          message: 'Credenciales inválidas',
          error: 'INVALID_CREDENTIALS'
        });
      }

      // Generar tokens
      const userData = {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role
      };

      const accessToken = generateAccessToken(userData);
      const refreshToken = generateRefreshToken(userData);

      // Guardar refresh token
      saveRefreshToken(user.id, refreshToken)
        .then(() => {
          res.json({
            message: 'Inicio de sesión exitoso',
            user: userData,
            accessToken,
            refreshToken
          });
        })
        .catch(err => {
          console.error('Error guardando refresh token:', err);
          res.status(500).json({
            message: 'Error en la autenticación',
            error: 'TOKEN_ERROR'
          });
        });
    });
  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({
      message: 'Error interno del servidor',
      error: 'INTERNAL_ERROR'
    });
  }
});

// POST /api/auth/logout - Cerrar sesión
router.post('/logout', authenticateToken, async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      // Eliminar refresh token de la base de datos
      await removeRefreshToken(refreshToken);
    }

    res.json({
      message: 'Sesión cerrada exitosamente'
    });
  } catch (error) {
    console.error('Error en logout:', error);
    res.status(500).json({
      message: 'Error cerrando sesión',
      error: 'INTERNAL_ERROR'
    });
  }
});

// POST /api/auth/refresh - Renovar access token
router.post('/refresh', authenticateRefreshToken, async (req, res) => {
  try {
    const user = req.user;
    const oldRefreshToken = req.refreshToken;

    // Generar nuevos tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    // Eliminar el refresh token anterior
    await removeRefreshToken(oldRefreshToken);

    // Guardar el nuevo refresh token
    await saveRefreshToken(user.id, refreshToken);

    res.json({
      message: 'Token renovado exitosamente',
      accessToken,
      refreshToken
    });
  } catch (error) {
    console.error('Error renovando token:', error);
    res.status(500).json({
      message: 'Error renovando token',
      error: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/auth/me - Obtener información del usuario actual
router.get('/me', authenticateToken, (req, res) => {
  res.json({
    user: req.user
  });
});

module.exports = router; 