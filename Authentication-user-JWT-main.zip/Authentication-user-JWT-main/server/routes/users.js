const express = require('express');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { getDatabase } = require('../database/init');

const router = express.Router();

// GET /api/users/profile - Obtener perfil del usuario (protegido)
router.get('/profile', authenticateToken, (req, res) => {
  try {
    res.json({
      message: 'Perfil obtenido exitosamente',
      user: req.user,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error obteniendo perfil:', error);
    res.status(500).json({
      message: 'Error obteniendo perfil',
      error: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/users/protected - Ruta protegida de ejemplo
router.get('/protected', authenticateToken, (req, res) => {
  res.json({
    message: '¡Acceso autorizado! Esta es una ruta protegida',
    user: req.user,
    data: {
      secretMessage: 'Este mensaje solo es visible para usuarios autenticados',
      timestamp: new Date().toISOString(),
      tokenInfo: {
        userId: req.user.id,
        userRole: req.user.role,
        userEmail: req.user.email
      }
    }
  });
});

// GET /api/users/admin - Ruta solo para administradores
router.get('/admin', authenticateToken, authorizeRole(['admin']), (req, res) => {
  const db = getDatabase();
  
  // Obtener todos los usuarios (solo para admins)
  const getAllUsers = `SELECT id, email, name, role, created_at FROM users`;
  
  db.all(getAllUsers, (err, users) => {
    if (err) {
      return res.status(500).json({
        message: 'Error obteniendo usuarios',
        error: 'DATABASE_ERROR'
      });
    }

    res.json({
      message: 'Panel de administración - Lista de usuarios',
      totalUsers: users.length,
      users: users,
      adminInfo: {
        adminId: req.user.id,
        adminName: req.user.name,
        timestamp: new Date().toISOString()
      }
    });
  });
});

// PUT /api/users/profile - Actualizar perfil del usuario
router.put('/profile', authenticateToken, (req, res) => {
  try {
    const { name, email } = req.body;
    const userId = req.user.id;

    if (!name && !email) {
      return res.status(400).json({
        message: 'Al menos un campo debe ser proporcionado',
        error: 'MISSING_FIELDS'
      });
    }

    const db = getDatabase();
    let updateQuery = 'UPDATE users SET updated_at = CURRENT_TIMESTAMP';
    let params = [];

    if (name) {
      updateQuery += ', name = ?';
      params.push(name);
    }

    if (email) {
      updateQuery += ', email = ?';
      params.push(email);
    }

    updateQuery += ' WHERE id = ?';
    params.push(userId);

    db.run(updateQuery, params, function(err) {
      if (err) {
        return res.status(500).json({
          message: 'Error actualizando perfil',
          error: 'DATABASE_ERROR'
        });
      }

      if (this.changes === 0) {
        return res.status(404).json({
          message: 'Usuario no encontrado',
          error: 'USER_NOT_FOUND'
        });
      }

      // Obtener usuario actualizado
      const getUser = `SELECT id, email, name, role FROM users WHERE id = ?`;
      db.get(getUser, [userId], (err, updatedUser) => {
        if (err) {
          return res.status(500).json({
            message: 'Error obteniendo usuario actualizado',
            error: 'DATABASE_ERROR'
          });
        }

        res.json({
          message: 'Perfil actualizado exitosamente',
          user: updatedUser,
          timestamp: new Date().toISOString()
        });
      });
    });
  } catch (error) {
    console.error('Error actualizando perfil:', error);
    res.status(500).json({
      message: 'Error interno del servidor',
      error: 'INTERNAL_ERROR'
    });
  }
});

// DELETE /api/users/profile - Eliminar cuenta del usuario
router.delete('/profile', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    const db = getDatabase();

    // Eliminar refresh tokens del usuario
    const deleteTokens = `DELETE FROM refresh_tokens WHERE user_id = ?`;
    db.run(deleteTokens, [userId], (err) => {
      if (err) {
        console.error('Error eliminando tokens:', err);
      }

      // Eliminar usuario
      const deleteUser = `DELETE FROM users WHERE id = ?`;
      db.run(deleteUser, [userId], function(err) {
        if (err) {
          return res.status(500).json({
            message: 'Error eliminando cuenta',
            error: 'DATABASE_ERROR'
          });
        }

        if (this.changes === 0) {
          return res.status(404).json({
            message: 'Usuario no encontrado',
            error: 'USER_NOT_FOUND'
          });
        }

        res.json({
          message: 'Cuenta eliminada exitosamente',
          timestamp: new Date().toISOString()
        });
      });
    });
  } catch (error) {
    console.error('Error eliminando cuenta:', error);
    res.status(500).json({
      message: 'Error interno del servidor',
      error: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/users/stats - Estadísticas (solo para usuarios autenticados)
router.get('/stats', authenticateToken, (req, res) => {
  const db = getDatabase();
  
  const getStats = `
    SELECT 
      COUNT(*) as totalUsers,
      COUNT(CASE WHEN role = 'admin' THEN 1 END) as adminUsers,
      COUNT(CASE WHEN role = 'user' THEN 1 END) as regularUsers,
      MIN(created_at) as oldestUser,
      MAX(created_at) as newestUser
    FROM users
  `;
  
  db.get(getStats, (err, stats) => {
    if (err) {
      return res.status(500).json({
        message: 'Error obteniendo estadísticas',
        error: 'DATABASE_ERROR'
      });
    }

    res.json({
      message: 'Estadísticas de usuarios',
      stats: {
        ...stats,
        currentUser: {
          id: req.user.id,
          name: req.user.name,
          role: req.user.role
        },
        timestamp: new Date().toISOString()
      }
    });
  });
});

module.exports = router; 