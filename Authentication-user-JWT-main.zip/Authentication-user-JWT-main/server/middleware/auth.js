const jwt = require('jsonwebtoken');
const { getDatabase } = require('../database/init');

// Middleware para verificar JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ 
      message: 'Token de acceso requerido',
      error: 'MISSING_TOKEN'
    });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ 
          message: 'Token expirado',
          error: 'TOKEN_EXPIRED'
        });
      }
      return res.status(403).json({ 
        message: 'Token inválido',
        error: 'INVALID_TOKEN'
      });
    }

    // Verificar que el usuario aún existe en la base de datos
    const db = getDatabase();
    const checkUser = `SELECT id, email, name, role FROM users WHERE id = ?`;
    
    db.get(checkUser, [user.id], (err, row) => {
      if (err) {
        return res.status(500).json({ 
          message: 'Error verificando usuario',
          error: 'DATABASE_ERROR'
        });
      }

      if (!row) {
        return res.status(403).json({ 
          message: 'Usuario no encontrado',
          error: 'USER_NOT_FOUND'
        });
      }

      // Agregar información del usuario al request
      req.user = {
        id: row.id,
        email: row.email,
        name: row.name,
        role: row.role
      };
      
      next();
    });
  });
};

// Middleware para verificar roles específicos
const authorizeRole = (roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ 
        message: 'Usuario no autenticado',
        error: 'NOT_AUTHENTICATED'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        message: 'Acceso denegado. Rol insuficiente.',
        error: 'INSUFFICIENT_PERMISSIONS',
        requiredRoles: roles,
        userRole: req.user.role
      });
    }

    next();
  };
};

// Middleware para verificar refresh token
const authenticateRefreshToken = (req, res, next) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(401).json({ 
      message: 'Refresh token requerido',
      error: 'MISSING_REFRESH_TOKEN'
    });
  }

  jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ 
          message: 'Refresh token expirado',
          error: 'REFRESH_TOKEN_EXPIRED'
        });
      }
      return res.status(403).json({ 
        message: 'Refresh token inválido',
        error: 'INVALID_REFRESH_TOKEN'
      });
    }

    // Verificar que el refresh token existe en la base de datos
    const db = getDatabase();
    const checkToken = `
      SELECT rt.*, u.id, u.email, u.name, u.role 
      FROM refresh_tokens rt 
      JOIN users u ON rt.user_id = u.id 
      WHERE rt.token = ? AND rt.expires_at > datetime('now')
    `;
    
    db.get(checkToken, [refreshToken], (err, row) => {
      if (err) {
        return res.status(500).json({ 
          message: 'Error verificando refresh token',
          error: 'DATABASE_ERROR'
        });
      }

      if (!row) {
        return res.status(403).json({ 
          message: 'Refresh token no válido o expirado',
          error: 'INVALID_REFRESH_TOKEN'
        });
      }

      req.user = {
        id: row.id,
        email: row.email,
        name: row.name,
        role: row.role
      };
      req.refreshToken = refreshToken;
      
      next();
    });
  });
};

module.exports = {
  authenticateToken,
  authorizeRole,
  authenticateRefreshToken
}; 