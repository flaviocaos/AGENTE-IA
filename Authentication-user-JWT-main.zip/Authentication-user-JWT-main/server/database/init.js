const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'jwt_auth.db');
const db = new sqlite3.Database(dbPath);

function initializeDatabase() {
  return new Promise((resolve, reject) => {
    // Crear tabla de usuarios
    const createUsersTable = `
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Crear tabla de refresh tokens (opcional para blacklist)
    const createRefreshTokensTable = `
      CREATE TABLE IF NOT EXISTS refresh_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT UNIQUE NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    `;

    db.serialize(() => {
      db.run(createUsersTable, (err) => {
        if (err) {
          console.error('Error creando tabla users:', err);
          reject(err);
          return;
        }
        console.log('✅ Tabla users creada/verificada');
      });

      db.run(createRefreshTokensTable, (err) => {
        if (err) {
          console.error('Error creando tabla refresh_tokens:', err);
          reject(err);
          return;
        }
        console.log('✅ Tabla refresh_tokens creada/verificada');
      });

      // Insertar usuario de prueba si no existe
      const checkUser = `SELECT COUNT(*) as count FROM users WHERE email = 'admin@test.com'`;
      db.get(checkUser, (err, row) => {
        if (err) {
          console.error('Error verificando usuario de prueba:', err);
          reject(err);
          return;
        }

        if (row.count === 0) {
          const bcrypt = require('bcryptjs');
          const hashedPassword = bcrypt.hashSync('admin123', 10);
          
          const insertTestUser = `
            INSERT INTO users (email, password, name, role) 
            VALUES (?, ?, ?, ?)
          `;
          
          db.run(insertTestUser, ['admin@test.com', hashedPassword, 'Administrador', 'admin'], (err) => {
            if (err) {
              console.error('Error insertando usuario de prueba:', err);
              reject(err);
              return;
            }
            console.log('✅ Usuario de prueba creado: admin@test.com / admin123');
            resolve();
          });
        } else {
          console.log('✅ Usuario de prueba ya existe');
          resolve();
        }
      });
    });
  });
}

// Función para obtener la conexión a la base de datos
function getDatabase() {
  return db;
}

module.exports = {
  initializeDatabase,
  getDatabase
}; 