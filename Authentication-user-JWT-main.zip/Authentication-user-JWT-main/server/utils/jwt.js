const jwt = require('jsonwebtoken');
const { getDatabase } = require('../database/init');

// Generar access token
const generateAccessToken = (user) => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );
};

// Generar refresh token
const generateRefreshToken = (user) => {
  return jwt.sign(
    {
      id: user.id,
      type: 'refresh'
    },
    process.env.REFRESH_TOKEN_SECRET,
    { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN }
  );
};

// Guardar refresh token en la base de datos
const saveRefreshToken = (userId, refreshToken) => {
  return new Promise((resolve, reject) => {
    const db = getDatabase();
    
    // Calcular fecha de expiración
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 días
    
    const insertToken = `
      INSERT INTO refresh_tokens (user_id, token, expires_at) 
      VALUES (?, ?, ?)
    `;
    
    db.run(insertToken, [userId, refreshToken, expiresAt.toISOString()], function(err) {
      if (err) {
        reject(err);
      } else {
        resolve(this.lastID);
      }
    });
  });
};

// Eliminar refresh token de la base de datos
const removeRefreshToken = (refreshToken) => {
  return new Promise((resolve, reject) => {
    const db = getDatabase();
    
    const deleteToken = `DELETE FROM refresh_tokens WHERE token = ?`;
    
    db.run(deleteToken, [refreshToken], function(err) {
      if (err) {
        reject(err);
      } else {
        resolve(this.changes);
      }
    });
  });
};

// Limpiar tokens expirados
const cleanExpiredTokens = () => {
  return new Promise((resolve, reject) => {
    const db = getDatabase();
    
    const deleteExpired = `DELETE FROM refresh_tokens WHERE expires_at < datetime('now')`;
    
    db.run(deleteExpired, function(err) {
      if (err) {
        reject(err);
      } else {
        resolve(this.changes);
      }
    });
  });
};

// Verificar si un token está en la blacklist (opcional)
const isTokenBlacklisted = (token) => {
  return new Promise((resolve, reject) => {
    const db = getDatabase();
    
    const checkToken = `SELECT COUNT(*) as count FROM refresh_tokens WHERE token = ?`;
    
    db.get(checkToken, [token], (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row.count > 0);
      }
    });
  });
};

// Decodificar token sin verificar (para debugging)
const decodeToken = (token) => {
  try {
    return jwt.decode(token);
  } catch (error) {
    return null;
  }
};

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  saveRefreshToken,
  removeRefreshToken,
  cleanExpiredTokens,
  isTokenBlacklisted,
  decodeToken
}; 