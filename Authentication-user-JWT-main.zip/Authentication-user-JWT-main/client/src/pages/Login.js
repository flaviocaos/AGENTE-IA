import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Paso 1 del flujo JWT: Enviar credenciales al servidor
      await login(formData.email, formData.password);
      
      setSuccess('¡Inicio de sesión exitoso! Redirigiendo...');
      
      // Redirigir al dashboard después de un breve delay
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
      
    } catch (error) {
      setError(error.message || 'Error en el inicio de sesión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h1>🔑 Iniciar Sesión</h1>
        <p className="alert alert-info">
          <strong>Paso 1 del Flujo JWT:</strong> Envía tus credenciales para obtener un token de acceso.
        </p>

        {error && (
          <div className="alert alert-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        {success && (
          <div className="alert alert-success">
            <strong>Éxito:</strong> {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="tu@email.com"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Contraseña:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              placeholder="Tu contraseña"
            />
          </div>

          <button 
            type="submit" 
            className="btn" 
            disabled={loading}
          >
            {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
          </button>
        </form>

        <div style={{ marginTop: '20px', textAlign: 'center' }}>
          <p>¿No tienes cuenta? <Link to="/register">Regístrate aquí</Link></p>
        </div>

        <div className="alert alert-info" style={{ marginTop: '30px' }}>
          <h3>🧪 Datos de Prueba</h3>
          <p>Puedes usar estas credenciales para probar la aplicación:</p>
          <div style={{ background: '#f8f9fa', padding: '15px', borderRadius: '5px', marginTop: '10px' }}>
            <p><strong>Admin:</strong></p>
            <p>Email: <code>admin@test.com</code></p>
            <p>Contraseña: <code>admin123</code></p>
          </div>
        </div>

        <div style={{ marginTop: '30px' }}>
          <h3>📋 Proceso de Autenticación JWT</h3>
          <ol style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li><strong>Envío de credenciales:</strong> Se envían email y contraseña al servidor</li>
            <li><strong>Verificación:</strong> El servidor valida las credenciales en la base de datos</li>
            <li><strong>Generación de JWT:</strong> Si son válidas, se crea un token JWT</li>
            <li><strong>Respuesta:</strong> El servidor devuelve el token al cliente</li>
            <li><strong>Almacenamiento:</strong> El token se guarda en localStorage</li>
            <li><strong>Uso:</strong> El token se incluye en futuras peticiones</li>
          </ol>
        </div>
      </div>
    </div>
  );
};

export default Login; 