import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const AdminPanel = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('/api/users/admin');
      setUsers(response.data.users);
    } catch (error) {
      setError(error.response?.data?.message || 'Error obteniendo usuarios');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="loading">Cargando panel de administración...</div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <h1>👑 Panel de Administración</h1>
        <p className="alert alert-success">
          <strong>¡Acceso autorizado!</strong> Esta página solo es accesible para usuarios con rol de administrador.
        </p>

        {error && (
          <div className="alert alert-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-number">{user?.name}</div>
            <div className="stat-label">Administrador</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{users.length}</div>
            <div className="stat-label">Total Usuarios</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">
              {users.filter(u => u.role === 'admin').length}
            </div>
            <div className="stat-label">Administradores</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">
              {users.filter(u => u.role === 'user').length}
            </div>
            <div className="stat-label">Usuarios Regulares</div>
          </div>
        </div>

        <div className="card">
          <h2>👥 Lista de Usuarios</h2>
          <p>Gestión completa de todos los usuarios del sistema:</p>

          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
              <thead>
                <tr style={{ backgroundColor: '#f8f9fa' }}>
                  <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>ID</th>
                  <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Nombre</th>
                  <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Email</th>
                  <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Rol</th>
                  <th style={{ padding: '12px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Fecha de Creación</th>
                </tr>
              </thead>
              <tbody>
                {users.map((userItem) => (
                  <tr key={userItem.id} style={{ borderBottom: '1px solid #dee2e6' }}>
                    <td style={{ padding: '12px' }}>{userItem.id}</td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div 
                          className="user-avatar" 
                          style={{ width: '30px', height: '30px', fontSize: '12px' }}
                        >
                          {userItem.name.charAt(0).toUpperCase()}
                        </div>
                        {userItem.name}
                      </div>
                    </td>
                    <td style={{ padding: '12px' }}>{userItem.email}</td>
                    <td style={{ padding: '12px' }}>
                      <span style={{
                        padding: '4px 8px',
                        borderRadius: '12px',
                        fontSize: '12px',
                        fontWeight: 'bold',
                        backgroundColor: userItem.role === 'admin' ? '#dc3545' : '#28a745',
                        color: 'white'
                      }}>
                        {userItem.role}
                      </span>
                    </td>
                    <td style={{ padding: '12px' }}>
                      {new Date(userItem.created_at).toLocaleDateString('es-ES', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <h2>🔐 Control de Acceso Basado en Roles (RBAC)</h2>
          <p>Esta página demuestra el control de acceso basado en roles implementado con JWT:</p>
          
          <div className="alert alert-info">
            <h3>¿Cómo funciona?</h3>
            <ol style={{ marginLeft: '20px', marginTop: '10px' }}>
              <li><strong>Verificación de JWT:</strong> El middleware verifica que el token sea válido</li>
              <li><strong>Extracción de rol:</strong> Se extrae el rol del usuario del payload del JWT</li>
              <li><strong>Verificación de permisos:</strong> Se verifica que el rol sea 'admin'</li>
              <li><strong>Acceso denegado:</strong> Si el rol no es correcto, se bloquea el acceso</li>
              <li><strong>Acceso permitido:</strong> Solo administradores pueden ver esta página</li>
            </ol>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px', marginTop: '20px' }}>
            <div className="stat-card">
              <h3>✅ Usuarios Regulares</h3>
              <p>No pueden acceder a esta página</p>
              <p>Reciben error 403 - Acceso Denegado</p>
            </div>
            <div className="stat-card">
              <h3>👑 Administradores</h3>
              <p>Pueden acceder a esta página</p>
              <p>Pueden ver todos los usuarios</p>
            </div>
          </div>
        </div>

        <div className="card">
          <h2>🛡️ Seguridad Implementada</h2>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li><strong>Middleware de autenticación:</strong> Verifica JWT en cada petición</li>
            <li><strong>Middleware de autorización:</strong> Verifica roles específicos</li>
            <li><strong>Validación en servidor:</strong> Doble verificación de permisos</li>
            <li><strong>Protección de rutas:</strong> Rutas específicas para cada rol</li>
            <li><strong>Manejo de errores:</strong> Respuestas apropiadas para acceso denegado</li>
            <li><strong>Logs de seguridad:</strong> Registro de intentos de acceso</li>
          </ul>
        </div>

        <div className="alert alert-info">
          <h3>💡 Funcionalidades del Panel</h3>
          <p>Como administrador puedes:</p>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li>Ver todos los usuarios registrados</li>
            <li>Acceder a estadísticas del sistema</li>
            <li>Gestionar permisos y roles</li>
            <li>Monitorear actividad de usuarios</li>
            <li>Acceder a funcionalidades exclusivas</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel; 