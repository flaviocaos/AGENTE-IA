import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const Dashboard = () => {
  const { user, accessToken, refreshToken } = useAuth();
  const [protectedData, setProtectedData] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Función para obtener datos de ruta protegida
  const fetchProtectedData = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await axios.get('/api/users/protected');
      setProtectedData(response.data);
    } catch (error) {
      setError('Error obteniendo datos protegidos: ' + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  // Función para obtener estadísticas
  const fetchStats = async () => {
    try {
      const response = await axios.get('/api/users/stats');
      setStats(response.data.stats);
    } catch (error) {
      console.error('Error obteniendo estadísticas:', error);
    }
  };

  useEffect(() => {
    fetchProtectedData();
    fetchStats();
  }, []);

  return (
    <div className="container">
      <div className="card">
        <h1>📊 Dashboard</h1>
        <p className="alert alert-success">
          <strong>¡Bienvenido al Dashboard!</strong> Esta es una ruta protegida que solo es accesible con un JWT válido.
        </p>

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-number">{user?.name}</div>
            <div className="stat-label">Tu Nombre</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{user?.role}</div>
            <div className="stat-label">Tu Rol</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{user?.email}</div>
            <div className="stat-label">Tu Email</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{user?.id}</div>
            <div className="stat-label">Tu ID</div>
          </div>
        </div>

        <div className="card">
          <h2>🔐 Información del Token JWT</h2>
          <p>Tu token de acceso actual:</p>
          <div className="token-info">
            <strong>Access Token:</strong><br />
            <code>{accessToken ? `${accessToken.substring(0, 50)}...` : 'No disponible'}</code>
          </div>
          
          <div className="token-info">
            <strong>Refresh Token:</strong><br />
            <code>{refreshToken ? `${refreshToken.substring(0, 50)}...` : 'No disponible'}</code>
          </div>

          <button onClick={fetchProtectedData} className="btn" disabled={loading}>
            {loading ? 'Cargando...' : 'Obtener Datos Protegidos'}
          </button>
        </div>

        {error && (
          <div className="alert alert-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        {protectedData && (
          <div className="card">
            <h2>✅ Datos de Ruta Protegida</h2>
            <p className="alert alert-success">
              <strong>¡Éxito!</strong> Se obtuvieron datos de una ruta protegida usando tu JWT.
            </p>
            
            <div className="token-info">
              <strong>Respuesta del servidor:</strong><br />
              <pre>{JSON.stringify(protectedData, null, 2)}</pre>
            </div>
          </div>
        )}

        {stats && (
          <div className="card">
            <h2>📈 Estadísticas del Sistema</h2>
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-number">{stats.totalUsers}</div>
                <div className="stat-label">Total Usuarios</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{stats.adminUsers}</div>
                <div className="stat-label">Administradores</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{stats.regularUsers}</div>
                <div className="stat-label">Usuarios Regulares</div>
              </div>
            </div>
          </div>
        )}

        <div className="card">
          <h2>🔍 Cómo Funciona el JWT Aquí</h2>
          <ol style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li><strong>Autenticación:</strong> Tu JWT se envía automáticamente en el header Authorization</li>
            <li><strong>Verificación:</strong> El servidor verifica la firma y validez del token</li>
            <li><strong>Autorización:</strong> Si el token es válido, se permite el acceso a los datos</li>
            <li><strong>Respuesta:</strong> El servidor devuelve los datos protegidos</li>
            <li><strong>Renovación:</strong> Si el token expira, se renueva automáticamente</li>
          </ol>
        </div>

        <div className="alert alert-info">
          <h3>💡 Prueba las Funcionalidades</h3>
          <p>Desde aquí puedes:</p>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li>Ver tu información de perfil</li>
            <li>Acceder al panel de administración (si eres admin)</li>
            <li>Probar rutas protegidas</li>
            <li>Ver estadísticas del sistema</li>
            <li>Gestionar tu cuenta</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard; 