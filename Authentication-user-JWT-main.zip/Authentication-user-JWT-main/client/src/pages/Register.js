import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    // Validaciones del cliente
    if (formData.password !== formData.confirmPassword) {
      setError('Las contraseñas no coinciden');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      setLoading(false);
      return;
    }

    try {
      // Registrar nuevo usuario
      await register(formData.name, formData.email, formData.password);
      
      setSuccess('¡Usuario registrado exitosamente! Redirigiendo...');
      
      // Redirigir al dashboard después de un breve delay
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
      
    } catch (error) {
      setError(error.message || 'Error en el registro');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h1>📝 Registrarse</h1>
        <p className="alert alert-info">
          <strong>Crear nueva cuenta:</strong> Completa el formulario para crear tu cuenta y obtener acceso a JWT.
        </p>

        {error && (
          <div className="alert alert-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        {success && (
          <div className="alert alert-success">
            <strong>Éxito:</strong> {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Nombre completo:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="Tu nombre completo"
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="tu@email.com"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Contraseña:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              placeholder="Mínimo 6 caracteres"
              minLength="6"
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirmar contraseña:</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
              placeholder="Repite tu contraseña"
            />
          </div>

          <button 
            type="submit" 
            className="btn" 
            disabled={loading}
          >
            {loading ? 'Registrando...' : 'Registrarse'}
          </button>
        </form>

        <div style={{ marginTop: '20px', textAlign: 'center' }}>
          <p>¿Ya tienes cuenta? <Link to="/login">Inicia sesión aquí</Link></p>
        </div>

        <div style={{ marginTop: '30px' }}>
          <h3>🔒 Seguridad del Registro</h3>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li><strong>Encriptación:</strong> Las contraseñas se encriptan con bcrypt antes de guardarse</li>
            <li><strong>Validación:</strong> Se verifica que el email no esté duplicado</li>
            <li><strong>Tokens:</strong> Al registrarse se generan automáticamente JWT y refresh tokens</li>
            <li><strong>Roles:</strong> Los nuevos usuarios obtienen el rol "user" por defecto</li>
            <li><strong>Base de datos:</strong> Los datos se almacenan en SQLite con integridad referencial</li>
          </ul>
        </div>

        <div className="alert alert-info" style={{ marginTop: '30px' }}>
          <h3>💡 Información del Proceso</h3>
          <p>Al registrarte, el sistema:</p>
          <ol style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li>Valida que todos los campos estén completos</li>
            <li>Verifica que el email no esté en uso</li>
            <li>Encripta la contraseña con bcrypt</li>
            <li>Crea el usuario en la base de datos</li>
            <li>Genera tokens JWT de acceso y renovación</li>
            <li>Te autentica automáticamente</li>
          </ol>
        </div>
      </div>
    </div>
  );
};

export default Register; 