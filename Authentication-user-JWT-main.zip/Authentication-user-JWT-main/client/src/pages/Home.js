import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Home = () => {
  const { isAuthenticated, user } = useAuth();

  return (
    <div className="container">
      <div className="card">
        <h1>🔐 Aplicación de Autenticación JWT</h1>
        <p className="alert alert-info">
          Esta aplicación demuestra el flujo completo de autenticación usando JWT (JSON Web Tokens).
        </p>

        {isAuthenticated ? (
          <div className="alert alert-success">
            <h3>¡Bienvenido, {user?.name}!</h3>
            <p>Ya estás autenticado. Puedes acceder a las funcionalidades protegidas.</p>
            <Link to="/dashboard" className="btn">Ir al Dashboard</Link>
          </div>
        ) : (
          <div className="alert alert-info">
            <h3>¿Nuevo aquí?</h3>
            <p>Regístrate o inicia sesión para probar las funcionalidades de JWT.</p>
            <div>
              <Link to="/register" className="btn">Registrarse</Link>
              <Link to="/login" className="btn btn-secondary">Iniciar Sesión</Link>
            </div>
          </div>
        )}

        <h2>📋 Flujo JWT Implementado</h2>
        
        <div style={{ marginTop: '20px' }}>
          <h3>1. Inicio de Sesión (Login)</h3>
          <p>El usuario envía sus credenciales (email y contraseña) al servidor mediante POST a /api/auth/login.</p>
          
          <h3>2. Verificación de Credenciales</h3>
          <p>El servidor valida las credenciales contra la base de datos SQLite.</p>
          
          <h3>3. Generación del Token</h3>
          <p>Si las credenciales son correctas, se genera un JWT con:</p>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li><strong>Header:</strong> Tipo de token y algoritmo (HS256)</li>
            <li><strong>Payload:</strong> Datos del usuario (id, email, role, exp)</li>
            <li><strong>Firma:</strong> Se crea firmando con la clave secreta del servidor</li>
          </ul>
          
          <h3>4. Envío del Token al Cliente</h3>
          <p>El servidor devuelve el JWT al cliente junto con un refresh token.</p>
          
          <h3>5. Uso del Token en Solicitudes Futuras</h3>
          <p>En cada petición posterior, el cliente incluye el JWT en el encabezado Authorization: Bearer &lt;token&gt;</p>
          
          <h3>6. Verificación del Token por el Servidor</h3>
          <p>El servidor recibe el token, verifica su firma y validez antes de procesar la solicitud.</p>
          
          <h3>7. Acceso a Recursos Protegidos</h3>
          <p>Solo se permite el acceso si el JWT es válido y no ha expirado.</p>
          
          <h3>8. Cierre de Sesión (Logout)</h3>
          <p>El cliente elimina el token del localStorage y opcionalmente se invalida en el servidor.</p>
        </div>

        <h2>🛠️ Características Implementadas</h2>
        <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
          <li>✅ Registro de usuarios con validación</li>
          <li>✅ Inicio de sesión con JWT</li>
          <li>✅ Refresh tokens para renovar sesiones</li>
          <li>✅ Rutas protegidas con middleware de autenticación</li>
          <li>✅ Control de acceso basado en roles (admin/user)</li>
          <li>✅ Gestión de perfil de usuario</li>
          <li>✅ Panel de administración</li>
          <li>✅ Manejo automático de tokens expirados</li>
          <li>✅ Cierre de sesión seguro</li>
          <li>✅ Base de datos SQLite con encriptación de contraseñas</li>
        </ul>

        <h2>🔧 Tecnologías Utilizadas</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginTop: '20px' }}>
          <div className="stat-card">
            <div className="stat-number">Backend</div>
            <div className="stat-label">Node.js + Express</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">Frontend</div>
            <div className="stat-label">React + Context API</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">Base de Datos</div>
            <div className="stat-label">SQLite</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">Autenticación</div>
            <div className="stat-label">JWT + bcrypt</div>
          </div>
        </div>

        <div style={{ marginTop: '30px', textAlign: 'center' }}>
          <h3>🚀 ¿Listo para probar?</h3>
          {!isAuthenticated && (
            <div>
              <Link to="/register" className="btn">Crear Cuenta</Link>
              <Link to="/login" className="btn btn-secondary">Iniciar Sesión</Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home; 