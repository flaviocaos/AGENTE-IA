import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    email: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || ''
      });
    }
  }, [user]);

  // Obtener datos del perfil
  const fetchProfile = async () => {
    try {
      const response = await axios.get('/api/users/profile');
      setProfileData(response.data);
    } catch (error) {
      console.error('Error obteniendo perfil:', error);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await axios.put('/api/users/profile', formData);
      
      // Actualizar el contexto de autenticación
      updateUser(response.data.user);
      
      setSuccess('Perfil actualizado exitosamente');
      fetchProfile(); // Recargar datos del perfil
      
    } catch (error) {
      setError(error.response?.data?.message || 'Error actualizando perfil');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.')) {
      return;
    }

    setLoading(true);
    setError('');

    try {
      await axios.delete('/api/users/profile');
      setSuccess('Cuenta eliminada exitosamente. Redirigiendo...');
      
      // El logout se manejará automáticamente por el interceptor de axios
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
      
    } catch (error) {
      setError(error.response?.data?.message || 'Error eliminando cuenta');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h1>👤 Perfil de Usuario</h1>
        <p className="alert alert-info">
          <strong>Gestiona tu información:</strong> Actualiza tu perfil y gestiona tu cuenta.
        </p>

        {error && (
          <div className="alert alert-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        {success && (
          <div className="alert alert-success">
            <strong>Éxito:</strong> {success}
          </div>
        )}

        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-number">{user?.name}</div>
            <div className="stat-label">Nombre Actual</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{user?.email}</div>
            <div className="stat-label">Email Actual</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{user?.role}</div>
            <div className="stat-label">Rol</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{user?.id}</div>
            <div className="stat-label">ID de Usuario</div>
          </div>
        </div>

        <div className="card">
          <h2>✏️ Editar Perfil</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Nombre:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Tu nombre completo"
              />
            </div>

            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="tu@email.com"
              />
            </div>

            <button 
              type="submit" 
              className="btn" 
              disabled={loading}
            >
              {loading ? 'Actualizando...' : 'Actualizar Perfil'}
            </button>
          </form>
        </div>

        {profileData && (
          <div className="card">
            <h2>📊 Información del Perfil</h2>
            <div className="token-info">
              <strong>Datos del servidor:</strong><br />
              <pre>{JSON.stringify(profileData, null, 2)}</pre>
            </div>
          </div>
        )}

        <div className="card">
          <h2>⚠️ Zona de Peligro</h2>
          <div className="alert alert-error">
            <h3>Eliminar Cuenta</h3>
            <p>
              <strong>¡Atención!</strong> Esta acción eliminará permanentemente tu cuenta y todos tus datos.
              Esta acción no se puede deshacer.
            </p>
            <button 
              onClick={handleDeleteAccount} 
              className="btn btn-danger" 
              disabled={loading}
            >
              {loading ? 'Eliminando...' : 'Eliminar Mi Cuenta'}
            </button>
          </div>
        </div>

        <div className="card">
          <h2>🔐 Seguridad de la Cuenta</h2>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li><strong>Autenticación JWT:</strong> Tu sesión está protegida con tokens JWT</li>
            <li><strong>Verificación de identidad:</strong> Cada petición verifica tu token</li>
            <li><strong>Renovación automática:</strong> Los tokens se renuevan automáticamente</li>
            <li><strong>Cierre seguro:</strong> Al cerrar sesión se invalidan los tokens</li>
            <li><strong>Protección de rutas:</strong> Solo usuarios autenticados pueden acceder</li>
          </ul>
        </div>

        <div className="alert alert-info">
          <h3>💡 Información Técnica</h3>
          <p>Esta página demuestra:</p>
          <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
            <li>Uso de rutas protegidas con JWT</li>
            <li>Actualización de datos de usuario</li>
            <li>Manejo de errores de autenticación</li>
            <li>Eliminación segura de cuentas</li>
            <li>Actualización del contexto de autenticación</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Profile; 