import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const ProtectedRoute = ({ children, requiredRole }) => {
  const { isAuthenticated, user, loading } = useAuth();

  if (loading) {
    return <div className="loading">Cargando...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (requiredRole && user?.role !== requiredRole) {
    return (
      <div className="container">
        <div className="card">
          <div className="alert alert-error">
            <h2>Acceso Denegado</h2>
            <p>No tienes permisos para acceder a esta página.</p>
            <p>Rol requerido: <strong>{requiredRole}</strong></p>
            <p>Tu rol: <strong>{user?.role}</strong></p>
          </div>
        </div>
      </div>
    );
  }

  return children;
};

export default ProtectedRoute; 