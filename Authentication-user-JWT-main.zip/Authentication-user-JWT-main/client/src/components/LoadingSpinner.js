import React from 'react';

const LoadingSpinner = () => {
  return (
    <div className="loading">
      <div>
        <h2>🔐 JWT Auth App</h2>
        <p>Cargando aplicación...</p>
      </div>
    </div>
  );
};

export default LoadingSpinner; 