# 🤖 LangChain Chat Agent – Basic Conversation

This repository contains a simple implementation of a conversational agent using [LangChain](https://www.langchain.com/) and a chat model (such as GPT-4 or GPT-3.5) to enable basic conversations with a user.

## 🚀 Features

- Chat agent implementation using LangChain.
- Support for OpenAI models (GPT-4, GPT-3.5).
- Basic conversation flow with message history.
- Easy to extend with custom tools and chains.

## 🧠 What is LangChain?

LangChain is a framework for developing applications powered by language models, allowing integration with external data sources and interactive tools.

## 📦 Requirements

- Python 3.8+
- OpenAI API Key (loaded from `.env`)
- Dependencies listed in `requirements.txt`

## 📁 Project Structure

