#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/Engine.h"
#include "GlobalTriggerManager.generated.h"

// Forward declarations
class UObject;
class UWorld;

/**
 * @brief Delegado personalizado para funciones de trigger
 * Este delegado permite definir funciones que se ejecutarán cuando se active un trigger
 */
DECLARE_DYNAMIC_DELEGATE_OneParam(FTriggerDelegate, const FString&, TriggerData);

/**
 * @brief Estructura que contiene información de un trigger registrado
 */
USTRUCT(BlueprintType)
struct FTriggerInfo
{
    GENERATED_BODY()

    /** @brief Nombre único del trigger */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    FString TriggerName;

    /** @brief Descripción del trigger */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    FString Description;

    /** @brief Delegado que contiene la función a ejecutar */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    FTriggerDelegate TriggerFunction;

    /** @brief Indica si el trigger está activo */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    bool bIsActive;

    FTriggerInfo()
    {
        TriggerName = TEXT("");
        Description = TEXT("");
        bIsActive = true;
    }
};

/**
 * @brief Clase GlobalTriggerManager que implementa el patrón Singleton
 * 
 * Esta clase proporciona una gestión centralizada de triggers en todo el proyecto.
 * Utiliza el patrón Singleton para asegurar que solo existe una instancia
 * de esta clase en toda la aplicación.
 * 
 * Características principales:
 * - Patrón Singleton para instancia única
 * - Registro y ejecución de triggers
 * - Gestión de delegados dinámicos
 * - Acceso global desde cualquier parte del proyecto
 */
UCLASS(BlueprintType, Blueprintable)
class YOURPROJECT_API UGlobalTriggerManager : public UObject
{
    GENERATED_BODY()

public:
    /**
     * @brief Constructor por defecto
     */
    UGlobalTriggerManager();

    /**
     * @brief Destructor
     */
    virtual ~UGlobalTriggerManager();

    /**
     * @brief Obtiene la instancia única del GlobalTriggerManager (Patrón Singleton)
     * 
     * Este método implementa el patrón Singleton asegurando que solo existe
     * una instancia de GlobalTriggerManager en toda la aplicación.
     * 
     * @return Puntero a la instancia única de GlobalTriggerManager
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    static UGlobalTriggerManager* GetInstance();

    /**
     * @brief Registra un nuevo trigger en el sistema
     * 
     * @param TriggerName Nombre único del trigger
     * @param Description Descripción del trigger
     * @param TriggerFunction Delegado que contiene la función a ejecutar
     * @return true si el registro fue exitoso, false si ya existe un trigger con ese nombre
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool RegisterTrigger(const FString& TriggerName, const FString& Description, const FTriggerDelegate& TriggerFunction);

    /**
     * @brief Ejecuta un trigger registrado por su nombre
     * 
     * @param TriggerName Nombre del trigger a ejecutar
     * @param TriggerData Datos opcionales que se pasarán a la función del trigger
     * @return true si el trigger se ejecutó correctamente, false si no se encontró o no está activo
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool ExecuteTrigger(const FString& TriggerName, const FString& TriggerData = TEXT(""));

    /**
     * @brief Desactiva un trigger específico
     * 
     * @param TriggerName Nombre del trigger a desactivar
     * @return true si el trigger se desactivó correctamente, false si no se encontró
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool DeactivateTrigger(const FString& TriggerName);

    /**
     * @brief Activa un trigger específico
     * 
     * @param TriggerName Nombre del trigger a activar
     * @return true si el trigger se activó correctamente, false si no se encontró
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool ActivateTrigger(const FString& TriggerName);

    /**
     * @brief Elimina un trigger del sistema
     * 
     * @param TriggerName Nombre del trigger a eliminar
     * @return true si el trigger se eliminó correctamente, false si no se encontró
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool UnregisterTrigger(const FString& TriggerName);

    /**
     * @brief Verifica si existe un trigger con el nombre especificado
     * 
     * @param TriggerName Nombre del trigger a verificar
     * @return true si el trigger existe, false en caso contrario
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool DoesTriggerExist(const FString& TriggerName) const;

    /**
     * @brief Obtiene información de un trigger específico
     * 
     * @param TriggerName Nombre del trigger
     * @param OutTriggerInfo Información del trigger (solo válida si el método retorna true)
     * @return true si se encontró el trigger, false en caso contrario
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    bool GetTriggerInfo(const FString& TriggerName, FTriggerInfo& OutTriggerInfo) const;

    /**
     * @brief Obtiene una lista de todos los triggers registrados
     * 
     * @return Array con información de todos los triggers
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    TArray<FTriggerInfo> GetAllTriggers() const;

    /**
     * @brief Limpia todos los triggers registrados
     */
    UFUNCTION(BlueprintCallable, Category = "Global Trigger Manager")
    void ClearAllTriggers();

protected:
    /**
     * @brief Inicialización de la clase
     */
    virtual void BeginPlay() override;

private:
    /** @brief Instancia única del GlobalTriggerManager (Patrón Singleton) */
    static UGlobalTriggerManager* Instance;

    /** @brief Mapa que almacena todos los triggers registrados */
    UPROPERTY()
    TMap<FString, FTriggerInfo> RegisteredTriggers;

    /** @brief Indica si la instancia ha sido inicializada */
    static bool bIsInitialized;

    /**
     * @brief Inicializa la instancia del Singleton
     * 
     * Este método privado se encarga de crear la instancia única
     * del GlobalTriggerManager si no existe.
     */
    static void InitializeInstance();

    /**
     * @brief Limpia la instancia del Singleton
     * 
     * Este método se llama cuando se destruye la instancia
     * para limpiar recursos y resetear el puntero estático.
     */
    void CleanupInstance();
}; 