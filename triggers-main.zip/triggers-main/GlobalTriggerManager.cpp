#include "GlobalTriggerManager.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "HAL/Platform.h"

// Inicialización de variables estáticas del patrón Singleton
UGlobalTriggerManager* UGlobalTriggerManager::Instance = nullptr;
bool UGlobalTriggerManager::bIsInitialized = false;

/**
 * @brief Constructor de la clase GlobalTriggerManager
 * 
 * Inicializa la clase y establece los valores por defecto.
 * En el patrón Singleton, el constructor es privado o protegido
 * para evitar la creación directa de instancias.
 */
UGlobalTriggerManager::UGlobalTriggerManager()
{
    // Inicialización de la clase
    PrimaryActorTick.bCanEverTick = false;
    
    // Limpiar el mapa de triggers al crear la instancia
    RegisteredTriggers.Empty();
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Instancia creada"));
}

/**
 * @brief Destructor de la clase GlobalTriggerManager
 * 
 * Se encarga de limpiar recursos y resetear la instancia del Singleton
 * cuando se destruye la clase.
 */
UGlobalTriggerManager::~UGlobalTriggerManager()
{
    // Limpiar todos los triggers registrados
    ClearAllTriggers();
    
    // Limpiar la instancia del Singleton
    CleanupInstance();
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Instancia destruida"));
}

/**
 * @brief Obtiene la instancia única del GlobalTriggerManager (Patrón Singleton)
 * 
 * Este es el método principal del patrón Singleton. Asegura que solo
 * existe una instancia de GlobalTriggerManager en toda la aplicación.
 * 
 * @return Puntero a la instancia única de GlobalTriggerManager
 */
UGlobalTriggerManager* UGlobalTriggerManager::GetInstance()
{
    // Verificar si la instancia ya existe
    if (Instance == nullptr)
    {
        // Si no existe, inicializar la instancia
        InitializeInstance();
    }
    
    return Instance;
}

/**
 * @brief Inicializa la instancia del Singleton
 * 
 * Este método privado se encarga de crear la instancia única
 * del GlobalTriggerManager. Utiliza el sistema de objetos de Unreal
 * para crear la instancia de manera segura.
 */
void UGlobalTriggerManager::InitializeInstance()
{
    // Verificar que no se haya inicializado ya
    if (bIsInitialized)
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: Ya está inicializado"));
        return;
    }
    
    // Obtener el mundo actual para crear la instancia
    UWorld* World = nullptr;
    
    // Intentar obtener el mundo desde diferentes fuentes
    if (GEngine)
    {
        World = GEngine->GetWorld();
    }
    
    if (World == nullptr)
    {
        // Si no hay mundo disponible, crear la instancia sin mundo
        Instance = NewObject<UGlobalTriggerManager>();
    }
    else
    {
        // Crear la instancia en el mundo actual
        Instance = NewObject<UGlobalTriggerManager>(World);
    }
    
    // Marcar como inicializado
    bIsInitialized = true;
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Instancia inicializada"));
}

/**
 * @brief Limpia la instancia del Singleton
 * 
 * Este método se llama cuando se destruye la instancia
 * para limpiar recursos y resetear el puntero estático.
 */
void UGlobalTriggerManager::CleanupInstance()
{
    // Resetear el puntero estático
    Instance = nullptr;
    
    // Marcar como no inicializado
    bIsInitialized = false;
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Instancia limpiada"));
}

/**
 * @brief Registra un nuevo trigger en el sistema
 * 
 * @param TriggerName Nombre único del trigger
 * @param Description Descripción del trigger
 * @param TriggerFunction Delegado que contiene la función a ejecutar
 * @return true si el registro fue exitoso, false si ya existe un trigger con ese nombre
 */
bool UGlobalTriggerManager::RegisterTrigger(const FString& TriggerName, const FString& Description, const FTriggerDelegate& TriggerFunction)
{
    // Verificar que el nombre del trigger no esté vacío
    if (TriggerName.IsEmpty())
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se puede registrar un trigger con nombre vacío"));
        return false;
    }
    
    // Verificar si ya existe un trigger con ese nombre
    if (RegisteredTriggers.Contains(TriggerName))
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: Ya existe un trigger con el nombre '%s'"), *TriggerName);
        return false;
    }
    
    // Crear la información del trigger
    FTriggerInfo NewTriggerInfo;
    NewTriggerInfo.TriggerName = TriggerName;
    NewTriggerInfo.Description = Description;
    NewTriggerInfo.TriggerFunction = TriggerFunction;
    NewTriggerInfo.bIsActive = true;
    
    // Agregar el trigger al mapa
    RegisteredTriggers.Add(TriggerName, NewTriggerInfo);
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Trigger '%s' registrado exitosamente"), *TriggerName);
    
    return true;
}

/**
 * @brief Ejecuta un trigger registrado por su nombre
 * 
 * @param TriggerName Nombre del trigger a ejecutar
 * @param TriggerData Datos opcionales que se pasarán a la función del trigger
 * @return true si el trigger se ejecutó correctamente, false si no se encontró o no está activo
 */
bool UGlobalTriggerManager::ExecuteTrigger(const FString& TriggerName, const FString& TriggerData)
{
    // Verificar que el nombre del trigger no esté vacío
    if (TriggerName.IsEmpty())
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se puede ejecutar un trigger con nombre vacío"));
        return false;
    }
    
    // Buscar el trigger en el mapa
    FTriggerInfo* TriggerInfo = RegisteredTriggers.Find(TriggerName);
    
    if (TriggerInfo == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se encontró el trigger '%s'"), *TriggerName);
        return false;
    }
    
    // Verificar si el trigger está activo
    if (!TriggerInfo->bIsActive)
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: El trigger '%s' está desactivado"), *TriggerName);
        return false;
    }
    
    // Verificar si el delegado está enlazado
    if (!TriggerInfo->TriggerFunction.IsBound())
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: El trigger '%s' no tiene función enlazada"), *TriggerName);
        return false;
    }
    
    // Ejecutar el trigger
    try
    {
        TriggerInfo->TriggerFunction.Execute(TriggerData);
        UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Trigger '%s' ejecutado exitosamente"), *TriggerName);
        return true;
    }
    catch (...)
    {
        UE_LOG(LogTemp, Error, TEXT("GlobalTriggerManager: Error al ejecutar el trigger '%s'"), *TriggerName);
        return false;
    }
}

/**
 * @brief Desactiva un trigger específico
 * 
 * @param TriggerName Nombre del trigger a desactivar
 * @return true si el trigger se desactivó correctamente, false si no se encontró
 */
bool UGlobalTriggerManager::DeactivateTrigger(const FString& TriggerName)
{
    // Verificar que el nombre del trigger no esté vacío
    if (TriggerName.IsEmpty())
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se puede desactivar un trigger con nombre vacío"));
        return false;
    }
    
    // Buscar el trigger en el mapa
    FTriggerInfo* TriggerInfo = RegisteredTriggers.Find(TriggerName);
    
    if (TriggerInfo == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se encontró el trigger '%s' para desactivar"), *TriggerName);
        return false;
    }
    
    // Desactivar el trigger
    TriggerInfo->bIsActive = false;
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Trigger '%s' desactivado"), *TriggerName);
    
    return true;
}

/**
 * @brief Activa un trigger específico
 * 
 * @param TriggerName Nombre del trigger a activar
 * @return true si el trigger se activó correctamente, false si no se encontró
 */
bool UGlobalTriggerManager::ActivateTrigger(const FString& TriggerName)
{
    // Verificar que el nombre del trigger no esté vacío
    if (TriggerName.IsEmpty())
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se puede activar un trigger con nombre vacío"));
        return false;
    }
    
    // Buscar el trigger en el mapa
    FTriggerInfo* TriggerInfo = RegisteredTriggers.Find(TriggerName);
    
    if (TriggerInfo == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se encontró el trigger '%s' para activar"), *TriggerName);
        return false;
    }
    
    // Activar el trigger
    TriggerInfo->bIsActive = true;
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Trigger '%s' activado"), *TriggerName);
    
    return true;
}

/**
 * @brief Elimina un trigger del sistema
 * 
 * @param TriggerName Nombre del trigger a eliminar
 * @return true si el trigger se eliminó correctamente, false si no se encontró
 */
bool UGlobalTriggerManager::UnregisterTrigger(const FString& TriggerName)
{
    // Verificar que el nombre del trigger no esté vacío
    if (TriggerName.IsEmpty())
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se puede eliminar un trigger con nombre vacío"));
        return false;
    }
    
    // Verificar si el trigger existe
    if (!RegisteredTriggers.Contains(TriggerName))
    {
        UE_LOG(LogTemp, Warning, TEXT("GlobalTriggerManager: No se encontró el trigger '%s' para eliminar"), *TriggerName);
        return false;
    }
    
    // Eliminar el trigger del mapa
    RegisteredTriggers.Remove(TriggerName);
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: Trigger '%s' eliminado"), *TriggerName);
    
    return true;
}

/**
 * @brief Verifica si existe un trigger con el nombre especificado
 * 
 * @param TriggerName Nombre del trigger a verificar
 * @return true si el trigger existe, false en caso contrario
 */
bool UGlobalTriggerManager::DoesTriggerExist(const FString& TriggerName) const
{
    return RegisteredTriggers.Contains(TriggerName);
}

/**
 * @brief Obtiene información de un trigger específico
 * 
 * @param TriggerName Nombre del trigger
 * @param OutTriggerInfo Información del trigger (solo válida si el método retorna true)
 * @return true si se encontró el trigger, false en caso contrario
 */
bool UGlobalTriggerManager::GetTriggerInfo(const FString& TriggerName, FTriggerInfo& OutTriggerInfo) const
{
    // Verificar que el nombre del trigger no esté vacío
    if (TriggerName.IsEmpty())
    {
        return false;
    }
    
    // Buscar el trigger en el mapa
    const FTriggerInfo* TriggerInfo = RegisteredTriggers.Find(TriggerName);
    
    if (TriggerInfo == nullptr)
    {
        return false;
    }
    
    // Copiar la información del trigger
    OutTriggerInfo = *TriggerInfo;
    
    return true;
}

/**
 * @brief Obtiene una lista de todos los triggers registrados
 * 
 * @return Array con información de todos los triggers
 */
TArray<FTriggerInfo> UGlobalTriggerManager::GetAllTriggers() const
{
    TArray<FTriggerInfo> AllTriggers;
    
    // Iterar sobre todos los triggers registrados
    for (const auto& Pair : RegisteredTriggers)
    {
        AllTriggers.Add(Pair.Value);
    }
    
    return AllTriggers;
}

/**
 * @brief Limpia todos los triggers registrados
 */
void UGlobalTriggerManager::ClearAllTriggers()
{
    // Obtener el número de triggers antes de limpiar
    int32 NumTriggers = RegisteredTriggers.Num();
    
    // Limpiar el mapa
    RegisteredTriggers.Empty();
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: %d triggers eliminados"), NumTriggers);
}

/**
 * @brief Inicialización de la clase
 */
void UGlobalTriggerManager::BeginPlay()
{
    Super::BeginPlay();
    
    UE_LOG(LogTemp, Log, TEXT("GlobalTriggerManager: BeginPlay llamado"));
} 