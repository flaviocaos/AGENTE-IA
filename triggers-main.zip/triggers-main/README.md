# GlobalTriggerManager - Sistema de Triggers con Patrón Singleton

## Descripción

El `GlobalTriggerManager` es una clase que implementa el patrón de diseño **Singleton** en Unreal Engine para proporcionar un sistema centralizado de gestión de triggers (disparadores de eventos). Permite registrar y ejecutar funciones de manera global desde cualquier parte del proyecto.

## Características Principales

- ✅ **Patrón Singleton**: Garantiza una única instancia global
- ✅ **Gestión de Triggers**: Registro, ejecución y eliminación de triggers
- ✅ **Delegados Dinámicos**: Uso de delegados de Unreal Engine para funciones
- ✅ **Acceso Global**: Disponible desde cualquier clase del proyecto
- ✅ **Gestión de Estados**: Activación/desactivación de triggers
- ✅ **Logging Completo**: Sistema de logs para debugging
- ✅ **Blueprint Support**: Funciones disponibles en Blueprint

## Estructura de Archivos

```
├── GlobalTriggerManager.h          # Cabecera principal
├── GlobalTriggerManager.cpp        # Implementación principal
├── TriggerExample.h               # Clase de ejemplo
├── TriggerExample.cpp             # Implementación del ejemplo
└── README.md                      # Esta documentación
```

## Cómo Funciona el Patrón Singleton

### 1. Variables Estáticas
```cpp
// En GlobalTriggerManager.h
private:
    static UGlobalTriggerManager* Instance;  // Instancia única
    static bool bIsInitialized;              // Estado de inicialización
```

### 2. Método GetInstance()
```cpp
UGlobalTriggerManager* UGlobalTriggerManager::GetInstance()
{
    if (Instance == nullptr)
    {
        InitializeInstance();
    }
    return Instance;
}
```

### 3. Inicialización Segura
```cpp
void UGlobalTriggerManager::InitializeInstance()
{
    if (bIsInitialized) return;
    
    UWorld* World = GEngine ? GEngine->GetWorld() : nullptr;
    Instance = World ? NewObject<UGlobalTriggerManager>(World) 
                    : NewObject<UGlobalTriggerManager>();
    
    bIsInitialized = true;
}
```

## Uso Básico

### 1. Obtener la Instancia
```cpp
// Desde cualquier clase
UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
```

### 2. Registrar un Trigger
```cpp
// Crear el delegado
FTriggerDelegate MyDelegate;
MyDelegate.BindUFunction(this, FName("MyTriggerFunction"));

// Registrar el trigger
TriggerManager->RegisterTrigger(
    TEXT("MyTriggerName"),
    TEXT("Descripción del trigger"),
    MyDelegate
);
```

### 3. Ejecutar un Trigger
```cpp
// Ejecutar el trigger
TriggerManager->ExecuteTrigger(TEXT("MyTriggerName"), TEXT("Datos adicionales"));
```

### 4. Función del Trigger
```cpp
UFUNCTION(BlueprintCallable, Category = "My Category")
void MyTriggerFunction(const FString& TriggerData)
{
    UE_LOG(LogTemp, Log, TEXT("Trigger ejecutado con datos: %s"), *TriggerData);
    // Tu lógica aquí
}
```

## Ejemplo Completo

### Paso 1: Crear la Clase de Ejemplo
```cpp
// En TriggerExample.h
UCLASS(BlueprintType, Blueprintable)
class YOURPROJECT_API ATriggerExample : public AActor
{
    GENERATED_BODY()

public:
    // Función que se ejecutará cuando se active el trigger
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void OnPlayerHealthLow(const FString& TriggerData);

    // Registrar triggers
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void RegisterExampleTriggers();

private:
    UGlobalTriggerManager* TriggerManager;
};
```

### Paso 2: Implementar el Registro
```cpp
// En TriggerExample.cpp
void ATriggerExample::RegisterExampleTriggers()
{
    TriggerManager = UGlobalTriggerManager::GetInstance();
    
    // Crear y enlazar el delegado
    FTriggerDelegate HealthLowDelegate;
    HealthLowDelegate.BindUFunction(this, FName("OnPlayerHealthLow"));
    
    // Registrar el trigger
    TriggerManager->RegisterTrigger(
        TEXT("PlayerHealthLow"),
        TEXT("Se activa cuando la salud del jugador es baja"),
        HealthLowDelegate
    );
}
```

### Paso 3: Implementar la Función del Trigger
```cpp
void ATriggerExample::OnPlayerHealthLow(const FString& TriggerData)
{
    UE_LOG(LogTemp, Warning, TEXT("¡Salud del jugador baja! Datos: %s"), *TriggerData);
    
    // Mostrar mensaje en pantalla
    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, 
            FString::Printf(TEXT("¡ADVERTENCIA! Salud: %s"), *TriggerData));
    }
}
```

### Paso 4: Ejecutar el Trigger
```cpp
// Desde cualquier parte del código
UGlobalTriggerManager* Manager = UGlobalTriggerManager::GetInstance();
Manager->ExecuteTrigger(TEXT("PlayerHealthLow"), TEXT("Salud: 25%"));
```

## API Completa

### Métodos Principales

| Método | Descripción | Parámetros |
|--------|-------------|------------|
| `GetInstance()` | Obtiene la instancia única | Ninguno |
| `RegisterTrigger()` | Registra un nuevo trigger | `TriggerName`, `Description`, `TriggerFunction` |
| `ExecuteTrigger()` | Ejecuta un trigger | `TriggerName`, `TriggerData` (opcional) |
| `DeactivateTrigger()` | Desactiva un trigger | `TriggerName` |
| `ActivateTrigger()` | Activa un trigger | `TriggerName` |
| `UnregisterTrigger()` | Elimina un trigger | `TriggerName` |
| `DoesTriggerExist()` | Verifica si existe un trigger | `TriggerName` |
| `GetTriggerInfo()` | Obtiene información de un trigger | `TriggerName`, `OutTriggerInfo` |
| `GetAllTriggers()` | Obtiene todos los triggers | Ninguno |
| `ClearAllTriggers()` | Limpia todos los triggers | Ninguno |

### Estructura FTriggerInfo

```cpp
USTRUCT(BlueprintType)
struct FTriggerInfo
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    FString TriggerName;        // Nombre único del trigger

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    FString Description;        // Descripción del trigger

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    FTriggerDelegate TriggerFunction;  // Función a ejecutar

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger")
    bool bIsActive;             // Estado activo/inactivo
};
```

## Casos de Uso Comunes

### 1. Sistema de Eventos del Juego
```cpp
// Registrar eventos del juego
TriggerManager->RegisterTrigger("PlayerDeath", "Jugador muere", DeathDelegate);
TriggerManager->RegisterTrigger("LevelComplete", "Nivel completado", CompleteDelegate);
TriggerManager->RegisterTrigger("EnemySpawn", "Enemigo aparece", SpawnDelegate);
```

### 2. Sistema de Logros
```cpp
// Registrar logros
TriggerManager->RegisterTrigger("FirstKill", "Primera eliminación", FirstKillDelegate);
TriggerManager->RegisterTrigger("SpeedRun", "Completar nivel rápido", SpeedRunDelegate);
```

### 3. Sistema de UI
```cpp
// Registrar eventos de UI
TriggerManager->RegisterTrigger("ShowMainMenu", "Mostrar menú principal", MenuDelegate);
TriggerManager->RegisterTrigger("UpdateHUD", "Actualizar HUD", HUDDelegate);
```

## Ventajas del Patrón Singleton

### ✅ Ventajas
- **Acceso Global**: Disponible desde cualquier parte del proyecto
- **Instancia Única**: Garantiza consistencia en toda la aplicación
- **Gestión Centralizada**: Todos los triggers en un solo lugar
- **Fácil Debugging**: Logs centralizados para todos los eventos
- **Eficiencia**: No hay múltiples instancias consumiendo memoria

### ⚠️ Consideraciones
- **Estado Global**: Cambios afectan a toda la aplicación
- **Testing**: Puede ser más difícil de testear
- **Dependencias**: Otras clases dependen de la instancia global

## Integración con Blueprint

Todas las funciones principales están marcadas con `UFUNCTION(BlueprintCallable)`, lo que permite:

1. **Llamar funciones desde Blueprint**
2. **Registrar triggers desde Blueprint**
3. **Ejecutar triggers desde Blueprint**
4. **Verificar estados desde Blueprint**

### Ejemplo en Blueprint
```
1. Obtener GlobalTriggerManager (GetInstance)
2. Llamar RegisterTrigger con parámetros
3. Llamar ExecuteTrigger cuando sea necesario
```

## Logging y Debugging

El sistema incluye logging completo para facilitar el debugging:

```cpp
// Logs automáticos para:
// - Creación/destrucción de instancia
// - Registro de triggers
// - Ejecución de triggers
// - Errores y advertencias
```

### Ejemplo de Logs
```
LogTemp: GlobalTriggerManager: Instancia creada
LogTemp: GlobalTriggerManager: Trigger 'PlayerHealthLow' registrado exitosamente
LogTemp: GlobalTriggerManager: Trigger 'PlayerHealthLow' ejecutado exitosamente
```

## Configuración del Proyecto

### 1. Agregar Archivos
- Copia los archivos `.h` y `.cpp` a tu proyecto
- Asegúrate de que estén en la carpeta correcta de tu módulo

### 2. Actualizar Build.cs
```cpp
// En tu archivo Build.cs
PublicDependencyModuleNames.AddRange(new string[] { 
    "Core", 
    "CoreUObject", 
    "Engine" 
});
```

### 3. Compilar
- Compila el proyecto
- Las clases estarán disponibles en Blueprint y C++

## Ejemplo de Uso en Juego

### Escenario: Sistema de Salud del Jugador

```cpp
// En PlayerCharacter.h
UCLASS()
class APlayerCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    UFUNCTION()
    void OnHealthChanged(float NewHealth, float MaxHealth);

private:
    void CheckHealthTriggers(float HealthPercentage);
};

// En PlayerCharacter.cpp
void APlayerCharacter::OnHealthChanged(float NewHealth, float MaxHealth)
{
    float HealthPercentage = (NewHealth / MaxHealth) * 100.0f;
    CheckHealthTriggers(HealthPercentage);
}

void APlayerCharacter::CheckHealthTriggers(float HealthPercentage)
{
    UGlobalTriggerManager* Manager = UGlobalTriggerManager::GetInstance();
    
    if (HealthPercentage <= 25.0f)
    {
        Manager->ExecuteTrigger("PlayerHealthLow", 
            FString::Printf(TEXT("Salud: %.1f%%"), HealthPercentage));
    }
    
    if (HealthPercentage <= 10.0f)
    {
        Manager->ExecuteTrigger("PlayerHealthCritical", 
            FString::Printf(TEXT("Salud: %.1f%%"), HealthPercentage));
    }
}
```

## Conclusión

El `GlobalTriggerManager` proporciona una solución robusta y escalable para la gestión de eventos en Unreal Engine. El patrón Singleton garantiza consistencia y acceso global, mientras que la API completa permite una gestión flexible de triggers.

Este sistema es especialmente útil para:
- Juegos con múltiples sistemas interconectados
- Proyectos que requieren gestión centralizada de eventos
- Equipos que necesitan un sistema de comunicación entre módulos
- Proyectos que requieren debugging y logging detallado

¡El sistema está listo para usar en tu proyecto de Unreal Engine! 