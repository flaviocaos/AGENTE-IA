// UsageExample.cpp
// Este archivo muestra diferentes ejemplos de cómo usar el GlobalTriggerManager
// en diferentes contextos de Unreal Engine

#include "GlobalTriggerManager.h"
#include "Engine/Engine.h"
#include "Engine/World.h"

/**
 * @brief Ejemplo 1: Uso básico del GlobalTriggerManager
 * 
 * Este ejemplo muestra cómo obtener la instancia y registrar un trigger simple.
 */
void Example1_BasicUsage()
{
    // 1. Obtener la instancia del GlobalTriggerManager (Singleton)
    UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
    
    // 2. Verificar que la instancia se obtuvo correctamente
    if (!TriggerManager)
    {
        UE_LOG(LogTemp, Error, TEXT("No se pudo obtener la instancia del GlobalTriggerManager"));
        return;
    }
    
    // 3. Crear un delegado para la función del trigger
    FTriggerDelegate MyTriggerDelegate;
    
    // 4. Enlazar el delegado con una función (esto se haría en una clase real)
    // MyTriggerDelegate.BindUFunction(this, FName("MyTriggerFunction"));
    
    // 5. Registrar el trigger
    bool bSuccess = TriggerManager->RegisterTrigger(
        TEXT("MyFirstTrigger"),
        TEXT("Mi primer trigger de ejemplo"),
        MyTriggerDelegate
    );
    
    if (bSuccess)
    {
        UE_LOG(LogTemp, Log, TEXT("Trigger registrado exitosamente"));
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("Error al registrar el trigger"));
    }
}

/**
 * @brief Ejemplo 2: Sistema de eventos del juego
 * 
 * Este ejemplo muestra cómo crear un sistema de eventos para un juego.
 */
class AGameEventManager
{
public:
    // Funciones que se ejecutarán cuando se activen los triggers
    void OnPlayerDeath(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Warning, TEXT("¡Jugador ha muerto! Datos: %s"), *TriggerData);
        
        // Lógica del juego cuando el jugador muere
        // - Mostrar pantalla de game over
        // - Reproducir sonido de muerte
        // - Guardar progreso
    }
    
    void OnLevelComplete(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("¡Nivel completado! Datos: %s"), *TriggerData);
        
        // Lógica del juego cuando se completa un nivel
        // - Mostrar pantalla de victoria
        // - Actualizar puntuación
        // - Desbloquear siguiente nivel
    }
    
    void OnEnemyDefeated(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("¡Enemigo derrotado! Datos: %s"), *TriggerData);
        
        // Lógica del juego cuando se derrota un enemigo
        // - Actualizar contador de enemigos
        // - Reproducir efecto de sonido
        // - Otorgar puntos
    }
    
    // Función para registrar todos los eventos del juego
    void RegisterGameEvents()
    {
        UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
        
        if (!TriggerManager) return;
        
        // Crear delegados para cada evento
        FTriggerDelegate DeathDelegate;
        FTriggerDelegate CompleteDelegate;
        FTriggerDelegate DefeatDelegate;
        
        // Enlazar delegados con funciones (en una clase real usarías BindUFunction)
        // DeathDelegate.BindUFunction(this, FName("OnPlayerDeath"));
        // CompleteDelegate.BindUFunction(this, FName("OnLevelComplete"));
        // DefeatDelegate.BindUFunction(this, FName("OnEnemyDefeated"));
        
        // Registrar los triggers
        TriggerManager->RegisterTrigger("PlayerDeath", "Jugador muere", DeathDelegate);
        TriggerManager->RegisterTrigger("LevelComplete", "Nivel completado", CompleteDelegate);
        TriggerManager->RegisterTrigger("EnemyDefeated", "Enemigo derrotado", DefeatDelegate);
        
        UE_LOG(LogTemp, Log, TEXT("Eventos del juego registrados"));
    }
};

/**
 * @brief Ejemplo 3: Sistema de logros
 * 
 * Este ejemplo muestra cómo implementar un sistema de logros usando triggers.
 */
class AAchievementSystem
{
public:
    // Funciones para diferentes logros
    void OnFirstKill(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("¡Logro desbloqueado: Primera Eliminación!"));
        
        // Lógica del logro
        // - Mostrar notificación de logro
        // - Actualizar estadísticas
        // - Guardar progreso
    }
    
    void OnSpeedRun(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("¡Logro desbloqueado: Speed Run! Tiempo: %s"), *TriggerData);
        
        // Lógica del logro de speed run
        // - Verificar tiempo
        // - Mostrar animación especial
        // - Otorgar recompensa
    }
    
    void OnPerfectLevel(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("¡Logro desbloqueado: Nivel Perfecto!"));
        
        // Lógica del logro de nivel perfecto
        // - Verificar condiciones
        // - Mostrar celebración
        // - Desbloquear contenido especial
    }
    
    // Función para registrar todos los logros
    void RegisterAchievements()
    {
        UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
        
        if (!TriggerManager) return;
        
        // Crear delegados para cada logro
        FTriggerDelegate FirstKillDelegate;
        FTriggerDelegate SpeedRunDelegate;
        FTriggerDelegate PerfectLevelDelegate;
        
        // Enlazar delegados (en una clase real usarías BindUFunction)
        // FirstKillDelegate.BindUFunction(this, FName("OnFirstKill"));
        // SpeedRunDelegate.BindUFunction(this, FName("OnSpeedRun"));
        // PerfectLevelDelegate.BindUFunction(this, FName("OnPerfectLevel"));
        
        // Registrar los logros
        TriggerManager->RegisterTrigger("FirstKill", "Primera eliminación", FirstKillDelegate);
        TriggerManager->RegisterTrigger("SpeedRun", "Completar nivel rápidamente", SpeedRunDelegate);
        TriggerManager->RegisterTrigger("PerfectLevel", "Nivel perfecto", PerfectLevelDelegate);
        
        UE_LOG(LogTemp, Log, TEXT("Sistema de logros registrado"));
    }
};

/**
 * @brief Ejemplo 4: Sistema de UI
 * 
 * Este ejemplo muestra cómo usar triggers para actualizar la interfaz de usuario.
 */
class AUIManager
{
public:
    // Funciones para actualizar diferentes elementos de UI
    void OnHealthChanged(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("Actualizando UI de salud: %s"), *TriggerData);
        
        // Lógica para actualizar la barra de salud
        // - Actualizar valor de la barra
        // - Cambiar color según el valor
        // - Mostrar efectos visuales
    }
    
    void OnAmmoChanged(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("Actualizando UI de munición: %s"), *TriggerData);
        
        // Lógica para actualizar el contador de munición
        // - Actualizar número en pantalla
        // - Mostrar advertencia si es baja
        // - Reproducir sonido de recarga
    }
    
    void OnScoreChanged(const FString& TriggerData)
    {
        UE_LOG(LogTemp, Log, TEXT("Actualizando UI de puntuación: %s"), *TriggerData);
        
        // Lógica para actualizar la puntuación
        // - Actualizar contador
        // - Mostrar animación de puntos
        // - Verificar récords
    }
    
    // Función para registrar todos los eventos de UI
    void RegisterUIEvents()
    {
        UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
        
        if (!TriggerManager) return;
        
        // Crear delegados para cada evento de UI
        FTriggerDelegate HealthDelegate;
        FTriggerDelegate AmmoDelegate;
        FTriggerDelegate ScoreDelegate;
        
        // Enlazar delegados (en una clase real usarías BindUFunction)
        // HealthDelegate.BindUFunction(this, FName("OnHealthChanged"));
        // AmmoDelegate.BindUFunction(this, FName("OnAmmoChanged"));
        // ScoreDelegate.BindUFunction(this, FName("OnScoreChanged"));
        
        // Registrar los eventos de UI
        TriggerManager->RegisterTrigger("HealthChanged", "Salud del jugador cambió", HealthDelegate);
        TriggerManager->RegisterTrigger("AmmoChanged", "Munición cambió", AmmoDelegate);
        TriggerManager->RegisterTrigger("ScoreChanged", "Puntuación cambió", ScoreDelegate);
        
        UE_LOG(LogTemp, Log, TEXT("Eventos de UI registrados"));
    }
};

/**
 * @brief Ejemplo 5: Ejecución de triggers desde diferentes contextos
 * 
 * Este ejemplo muestra cómo ejecutar triggers desde diferentes partes del código.
 */
void Example5_ExecuteTriggers()
{
    UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
    
    if (!TriggerManager) return;
    
    // Ejecutar diferentes triggers con datos específicos
    TriggerManager->ExecuteTrigger("PlayerDeath", TEXT("Causa: Caída"));
    TriggerManager->ExecuteTrigger("LevelComplete", TEXT("Tiempo: 2:30"));
    TriggerManager->ExecuteTrigger("EnemyDefeated", TEXT("Tipo: Zombie"));
    TriggerManager->ExecuteTrigger("FirstKill", TEXT("Arma: Pistola"));
    TriggerManager->ExecuteTrigger("HealthChanged", TEXT("Salud: 75%"));
    TriggerManager->ExecuteTrigger("AmmoChanged", TEXT("Munición: 15/30"));
    TriggerManager->ExecuteTrigger("ScoreChanged", TEXT("Puntos: 1500"));
}

/**
 * @brief Ejemplo 6: Gestión de estados de triggers
 * 
 * Este ejemplo muestra cómo activar, desactivar y gestionar triggers.
 */
void Example6_TriggerManagement()
{
    UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
    
    if (!TriggerManager) return;
    
    // Verificar si existe un trigger
    if (TriggerManager->DoesTriggerExist("PlayerDeath"))
    {
        UE_LOG(LogTemp, Log, TEXT("El trigger PlayerDeath existe"));
        
        // Obtener información del trigger
        FTriggerInfo TriggerInfo;
        if (TriggerManager->GetTriggerInfo("PlayerDeath", TriggerInfo))
        {
            UE_LOG(LogTemp, Log, TEXT("Trigger: %s - %s"), 
                *TriggerInfo.TriggerName, *TriggerInfo.Description);
        }
        
        // Desactivar temporalmente el trigger
        TriggerManager->DeactivateTrigger("PlayerDeath");
        UE_LOG(LogTemp, Log, TEXT("Trigger PlayerDeath desactivado"));
        
        // Intentar ejecutar el trigger (no debería funcionar)
        bool bExecuted = TriggerManager->ExecuteTrigger("PlayerDeath", TEXT("Test"));
        if (!bExecuted)
        {
            UE_LOG(LogTemp, Log, TEXT("Trigger no se ejecutó (está desactivado)"));
        }
        
        // Reactivar el trigger
        TriggerManager->ActivateTrigger("PlayerDeath");
        UE_LOG(LogTemp, Log, TEXT("Trigger PlayerDeath reactivado"));
        
        // Ahora sí debería ejecutarse
        bExecuted = TriggerManager->ExecuteTrigger("PlayerDeath", TEXT("Test"));
        if (bExecuted)
        {
            UE_LOG(LogTemp, Log, TEXT("Trigger ejecutado correctamente"));
        }
    }
    
    // Mostrar todos los triggers registrados
    TArray<FTriggerInfo> AllTriggers = TriggerManager->GetAllTriggers();
    UE_LOG(LogTemp, Log, TEXT("Total de triggers registrados: %d"), AllTriggers.Num());
    
    for (const FTriggerInfo& Trigger : AllTriggers)
    {
        FString Status = Trigger.bIsActive ? TEXT("Activo") : TEXT("Inactivo");
        UE_LOG(LogTemp, Log, TEXT("  - %s: %s (%s)"), 
            *Trigger.TriggerName, *Trigger.Description, *Status);
    }
}

/**
 * @brief Ejemplo 7: Limpieza y eliminación de triggers
 * 
 * Este ejemplo muestra cómo limpiar y eliminar triggers del sistema.
 */
void Example7_CleanupTriggers()
{
    UGlobalTriggerManager* TriggerManager = UGlobalTriggerManager::GetInstance();
    
    if (!TriggerManager) return;
    
    // Eliminar un trigger específico
    bool bRemoved = TriggerManager->UnregisterTrigger("PlayerDeath");
    if (bRemoved)
    {
        UE_LOG(LogTemp, Log, TEXT("Trigger PlayerDeath eliminado"));
    }
    
    // Verificar que ya no existe
    if (!TriggerManager->DoesTriggerExist("PlayerDeath"))
    {
        UE_LOG(LogTemp, Log, TEXT("Confirmado: PlayerDeath ya no existe"));
    }
    
    // Limpiar todos los triggers
    TriggerManager->ClearAllTriggers();
    UE_LOG(LogTemp, Log, TEXT("Todos los triggers eliminados"));
    
    // Verificar que no quedan triggers
    TArray<FTriggerInfo> AllTriggers = TriggerManager->GetAllTriggers();
    UE_LOG(LogTemp, Log, TEXT("Triggers restantes: %d"), AllTriggers.Num());
}

/**
 * @brief Función principal de ejemplo que ejecuta todos los casos de uso
 * 
 * Esta función puede ser llamada desde cualquier parte del código para
 * demostrar el uso completo del GlobalTriggerManager.
 */
void RunAllExamples()
{
    UE_LOG(LogTemp, Log, TEXT("=== INICIANDO EJEMPLOS DE GLOBALTRIGGERMANAGER ==="));
    
    // Ejemplo 1: Uso básico
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 1: Uso Básico ---"));
    Example1_BasicUsage();
    
    // Ejemplo 2: Sistema de eventos del juego
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 2: Sistema de Eventos del Juego ---"));
    AGameEventManager GameManager;
    GameManager.RegisterGameEvents();
    
    // Ejemplo 3: Sistema de logros
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 3: Sistema de Logros ---"));
    AAchievementSystem AchievementSystem;
    AchievementSystem.RegisterAchievements();
    
    // Ejemplo 4: Sistema de UI
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 4: Sistema de UI ---"));
    AUIManager UIManager;
    UIManager.RegisterUIEvents();
    
    // Ejemplo 5: Ejecución de triggers
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 5: Ejecución de Triggers ---"));
    Example5_ExecuteTriggers();
    
    // Ejemplo 6: Gestión de estados
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 6: Gestión de Estados ---"));
    Example6_TriggerManagement();
    
    // Ejemplo 7: Limpieza
    UE_LOG(LogTemp, Log, TEXT("--- Ejemplo 7: Limpieza ---"));
    Example7_CleanupTriggers();
    
    UE_LOG(LogTemp, Log, TEXT("=== EJEMPLOS COMPLETADOS ==="));
}

// Nota: Para usar estos ejemplos en tu proyecto:
// 1. Copia este código a un archivo .cpp en tu proyecto
// 2. Incluye los headers necesarios
// 3. Llama a RunAllExamples() desde donde necesites
// 4. Asegúrate de que GlobalTriggerManager esté compilado y disponible 