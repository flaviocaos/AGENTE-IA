#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GlobalTriggerManager.h"
#include "TriggerExample.generated.h"

/**
 * @brief Clase de ejemplo que demuestra cómo usar el GlobalTriggerManager
 * 
 * Esta clase muestra cómo:
 * 1. Registrar triggers en el GlobalTriggerManager
 * 2. Ejecutar triggers desde cualquier parte del código
 * 3. Manejar eventos usando el patrón Singleton
 * 
 * Es un ejemplo práctico de cómo implementar un sistema de eventos
 * centralizado usando el patrón Singleton en Unreal Engine.
 */
UCLASS(BlueprintType, Blueprintable)
class YOURPROJECT_API ATriggerExample : public AActor
{
    GENERATED_BODY()

public:
    /**
     * @brief Constructor por defecto
     */
    ATriggerExample();

protected:
    /**
     * @brief Llamado cuando el juego comienza o cuando se genera el actor
     */
    virtual void BeginPlay() override;

    /**
     * @brief Llamado cada frame
     */
    virtual void Tick(float DeltaTime) override;

public:
    /**
     * @brief Función que se ejecutará cuando se active el trigger "PlayerHealthLow"
     * 
     * @param TriggerData Datos adicionales del trigger (por ejemplo, el valor de salud actual)
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void OnPlayerHealthLow(const FString& TriggerData);

    /**
     * @brief Función que se ejecutará cuando se active el trigger "EnemyDefeated"
     * 
     * @param TriggerData Datos adicionales del trigger (por ejemplo, el tipo de enemigo)
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void OnEnemyDefeated(const FString& TriggerData);

    /**
     * @brief Función que se ejecutará cuando se active el trigger "LevelCompleted"
     * 
     * @param TriggerData Datos adicionales del trigger (por ejemplo, el tiempo completado)
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void OnLevelCompleted(const FString& TriggerData);

    /**
     * @brief Registra todos los triggers de ejemplo en el GlobalTriggerManager
     * 
     * Esta función demuestra cómo registrar triggers usando el patrón Singleton.
     * Los triggers se registran una sola vez y pueden ser ejecutados desde
     * cualquier parte del proyecto.
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void RegisterExampleTriggers();

    /**
     * @brief Simula la activación de triggers de ejemplo
     * 
     * Esta función demuestra cómo ejecutar triggers desde cualquier clase
     * usando el GlobalTriggerManager.
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void SimulateTriggerActivations();

    /**
     * @brief Ejecuta un trigger específico por nombre
     * 
     * @param TriggerName Nombre del trigger a ejecutar
     * @param TriggerData Datos adicionales para el trigger
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void ExecuteSpecificTrigger(const FString& TriggerName, const FString& TriggerData = TEXT(""));

    /**
     * @brief Muestra información de todos los triggers registrados
     */
    UFUNCTION(BlueprintCallable, Category = "Trigger Example")
    void ShowAllRegisteredTriggers();

private:
    /** @brief Referencia al GlobalTriggerManager (Singleton) */
    UPROPERTY()
    UGlobalTriggerManager* TriggerManager;

    /** @brief Contador para simular diferentes eventos */
    UPROPERTY()
    int32 EventCounter;

    /** @brief Timer para simular eventos automáticamente */
    UPROPERTY()
    float AutoEventTimer;

    /** @brief Intervalo entre eventos automáticos */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Trigger Example", meta = (AllowPrivateAccess = "true"))
    float AutoEventInterval;

    /**
     * @brief Configura el timer para eventos automáticos
     */
    void SetupAutoEventTimer();

    /**
     * @brief Maneja los eventos automáticos
     */
    void HandleAutoEvents();
}; 