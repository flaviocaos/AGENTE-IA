#include "TriggerExample.h"
#include "GlobalTriggerManager.h"
#include "Engine/Engine.h"
#include "Engine/World.h"

/**
 * @brief Constructor de la clase TriggerExample
 * 
 * Inicializa los valores por defecto y configura el actor.
 */
ATriggerExample::ATriggerExample()
{
    // Configurar el actor para que se actualice cada frame
    PrimaryActorTick.bCanEverTick = true;
    
    // Inicializar variables
    EventCounter = 0;
    AutoEventTimer = 0.0f;
    AutoEventInterval = 5.0f; // Eventos cada 5 segundos
    
    // Obtener la instancia del GlobalTriggerManager (Singleton)
    TriggerManager = UGlobalTriggerManager::GetInstance();
    
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: Actor creado"));
}

/**
 * @brief Llamado cuando el juego comienza o cuando se genera el actor
 * 
 * Aquí se registran los triggers de ejemplo y se configura el sistema.
 */
void ATriggerExample::BeginPlay()
{
    Super::BeginPlay();
    
    // Registrar los triggers de ejemplo
    RegisterExampleTriggers();
    
    // Configurar el timer para eventos automáticos
    SetupAutoEventTimer();
    
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: BeginPlay completado"));
}

/**
 * @brief Llamado cada frame
 * 
 * Aquí se manejan los eventos automáticos y otras actualizaciones.
 */
void ATriggerExample::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
    
    // Manejar eventos automáticos
    HandleAutoEvents();
}

/**
 * @brief Función que se ejecutará cuando se active el trigger "PlayerHealthLow"
 * 
 * @param TriggerData Datos adicionales del trigger (por ejemplo, el valor de salud actual)
 */
void ATriggerExample::OnPlayerHealthLow(const FString& TriggerData)
{
    UE_LOG(LogTemp, Warning, TEXT("TriggerExample: ¡Salud del jugador baja! Datos: %s"), *TriggerData);
    
    // Aquí puedes agregar lógica específica para cuando la salud del jugador es baja
    // Por ejemplo: mostrar UI de advertencia, reproducir sonido, etc.
    
    // Ejemplo: Mostrar un mensaje en pantalla
    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, 
            FString::Printf(TEXT("¡ADVERTENCIA! Salud del jugador baja: %s"), *TriggerData));
    }
}

/**
 * @brief Función que se ejecutará cuando se active el trigger "EnemyDefeated"
 * 
 * @param TriggerData Datos adicionales del trigger (por ejemplo, el tipo de enemigo)
 */
void ATriggerExample::OnEnemyDefeated(const FString& TriggerData)
{
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: ¡Enemigo derrotado! Tipo: %s"), *TriggerData);
    
    // Aquí puedes agregar lógica específica para cuando se derrota un enemigo
    // Por ejemplo: actualizar puntuación, reproducir efectos de sonido, etc.
    
    // Ejemplo: Mostrar un mensaje en pantalla
    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 2.0f, FColor::Green, 
            FString::Printf(TEXT("¡Enemigo derrotado! %s"), *TriggerData));
    }
}

/**
 * @brief Función que se ejecutará cuando se active el trigger "LevelCompleted"
 * 
 * @param TriggerData Datos adicionales del trigger (por ejemplo, el tiempo completado)
 */
void ATriggerExample::OnLevelCompleted(const FString& TriggerData)
{
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: ¡Nivel completado! Tiempo: %s"), *TriggerData);
    
    // Aquí puedes agregar lógica específica para cuando se completa un nivel
    // Por ejemplo: mostrar pantalla de victoria, guardar progreso, etc.
    
    // Ejemplo: Mostrar un mensaje en pantalla
    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Yellow, 
            FString::Printf(TEXT("¡NIVEL COMPLETADO! Tiempo: %s"), *TriggerData));
    }
}

/**
 * @brief Registra todos los triggers de ejemplo en el GlobalTriggerManager
 * 
 * Esta función demuestra cómo registrar triggers usando el patrón Singleton.
 * Los triggers se registran una sola vez y pueden ser ejecutados desde
 * cualquier parte del proyecto.
 */
void ATriggerExample::RegisterExampleTriggers()
{
    // Verificar que el TriggerManager esté disponible
    if (!TriggerManager)
    {
        UE_LOG(LogTemp, Error, TEXT("TriggerExample: No se pudo obtener la instancia del GlobalTriggerManager"));
        return;
    }
    
    // Crear delegados para cada función de trigger
    FTriggerDelegate HealthLowDelegate;
    FTriggerDelegate EnemyDefeatedDelegate;
    FTriggerDelegate LevelCompletedDelegate;
    
    // Enlazar los delegados con las funciones correspondientes
    HealthLowDelegate.BindUFunction(this, FName("OnPlayerHealthLow"));
    EnemyDefeatedDelegate.BindUFunction(this, FName("OnEnemyDefeated"));
    LevelCompletedDelegate.BindUFunction(this, FName("OnLevelCompleted"));
    
    // Registrar los triggers en el GlobalTriggerManager
    bool bHealthRegistered = TriggerManager->RegisterTrigger(
        TEXT("PlayerHealthLow"),
        TEXT("Se activa cuando la salud del jugador es baja"),
        HealthLowDelegate
    );
    
    bool bEnemyRegistered = TriggerManager->RegisterTrigger(
        TEXT("EnemyDefeated"),
        TEXT("Se activa cuando se derrota un enemigo"),
        EnemyDefeatedDelegate
    );
    
    bool bLevelRegistered = TriggerManager->RegisterTrigger(
        TEXT("LevelCompleted"),
        TEXT("Se activa cuando se completa un nivel"),
        LevelCompletedDelegate
    );
    
    // Mostrar resultados del registro
    if (bHealthRegistered && bEnemyRegistered && bLevelRegistered)
    {
        UE_LOG(LogTemp, Log, TEXT("TriggerExample: Todos los triggers registrados exitosamente"));
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("TriggerExample: Algunos triggers no se pudieron registrar"));
    }
}

/**
 * @brief Simula la activación de triggers de ejemplo
 * 
 * Esta función demuestra cómo ejecutar triggers desde cualquier clase
 * usando el GlobalTriggerManager.
 */
void ATriggerExample::SimulateTriggerActivations()
{
    // Verificar que el TriggerManager esté disponible
    if (!TriggerManager)
    {
        UE_LOG(LogTemp, Error, TEXT("TriggerExample: No se pudo obtener la instancia del GlobalTriggerManager"));
        return;
    }
    
    // Simular diferentes eventos
    switch (EventCounter % 3)
    {
        case 0:
            // Simular salud baja del jugador
            TriggerManager->ExecuteTrigger(TEXT("PlayerHealthLow"), TEXT("Salud: 25%"));
            break;
            
        case 1:
            // Simular enemigo derrotado
            TriggerManager->ExecuteTrigger(TEXT("EnemyDefeated"), TEXT("Tipo: Zombie"));
            break;
            
        case 2:
            // Simular nivel completado
            TriggerManager->ExecuteTrigger(TEXT("LevelCompleted"), TEXT("Tiempo: 2:30"));
            break;
    }
    
    EventCounter++;
    
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: Evento simulado #%d"), EventCounter);
}

/**
 * @brief Ejecuta un trigger específico por nombre
 * 
 * @param TriggerName Nombre del trigger a ejecutar
 * @param TriggerData Datos adicionales para el trigger
 */
void ATriggerExample::ExecuteSpecificTrigger(const FString& TriggerName, const FString& TriggerData)
{
    // Verificar que el TriggerManager esté disponible
    if (!TriggerManager)
    {
        UE_LOG(LogTemp, Error, TEXT("TriggerExample: No se pudo obtener la instancia del GlobalTriggerManager"));
        return;
    }
    
    // Verificar si el trigger existe
    if (!TriggerManager->DoesTriggerExist(TriggerName))
    {
        UE_LOG(LogTemp, Warning, TEXT("TriggerExample: El trigger '%s' no existe"), *TriggerName);
        return;
    }
    
    // Ejecutar el trigger
    bool bSuccess = TriggerManager->ExecuteTrigger(TriggerName, TriggerData);
    
    if (bSuccess)
    {
        UE_LOG(LogTemp, Log, TEXT("TriggerExample: Trigger '%s' ejecutado exitosamente"), *TriggerName);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("TriggerExample: Error al ejecutar el trigger '%s'"), *TriggerName);
    }
}

/**
 * @brief Muestra información de todos los triggers registrados
 */
void ATriggerExample::ShowAllRegisteredTriggers()
{
    // Verificar que el TriggerManager esté disponible
    if (!TriggerManager)
    {
        UE_LOG(LogTemp, Error, TEXT("TriggerExample: No se pudo obtener la instancia del GlobalTriggerManager"));
        return;
    }
    
    // Obtener todos los triggers registrados
    TArray<FTriggerInfo> AllTriggers = TriggerManager->GetAllTriggers();
    
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: Triggers registrados (%d):"), AllTriggers.Num());
    
    // Mostrar información de cada trigger
    for (const FTriggerInfo& TriggerInfo : AllTriggers)
    {
        FString Status = TriggerInfo.bIsActive ? TEXT("Activo") : TEXT("Inactivo");
        UE_LOG(LogTemp, Log, TEXT("  - %s: %s (%s)"), 
            *TriggerInfo.TriggerName, 
            *TriggerInfo.Description, 
            *Status);
    }
}

/**
 * @brief Configura el timer para eventos automáticos
 */
void ATriggerExample::SetupAutoEventTimer()
{
    AutoEventTimer = 0.0f;
    UE_LOG(LogTemp, Log, TEXT("TriggerExample: Timer de eventos automáticos configurado"));
}

/**
 * @brief Maneja los eventos automáticos
 */
void ATriggerExample::HandleAutoEvents()
{
    // Actualizar el timer
    AutoEventTimer += GetWorld()->GetDeltaSeconds();
    
    // Verificar si es tiempo de ejecutar un evento automático
    if (AutoEventTimer >= AutoEventInterval)
    {
        // Ejecutar un evento automático
        SimulateTriggerActivations();
        
        // Resetear el timer
        AutoEventTimer = 0.0f;
    }
} 