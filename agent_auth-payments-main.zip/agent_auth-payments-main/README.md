# agent_auth-payments
Agents App (apps/agents) Runtime: Node.js + TypeScript Framework: LangGraph.js AI: LangChain + Anthropic Auth: Langgraph Middleware Testing: Jest Package Manager: pnpm
