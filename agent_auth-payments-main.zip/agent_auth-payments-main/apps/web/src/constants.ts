export const DO_NOT_RENDER_ID_PREFIX = "do-not-render-";
export const DOCS_LINK = "https://docs.oap.langchain.com";
export const DESCRIPTION_MAX_LENGTH = 850;
