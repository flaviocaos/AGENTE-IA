"use client";

import SignupInterface from "@/features/signup";

export default function SignupPage() {
  return <SignupInterface />;
}
