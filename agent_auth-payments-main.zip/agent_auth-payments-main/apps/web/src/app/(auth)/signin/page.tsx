"use client";

import SigninInterface from "@/features/signin";

export default function SigninPage() {
  return <SigninInterface />;
}
